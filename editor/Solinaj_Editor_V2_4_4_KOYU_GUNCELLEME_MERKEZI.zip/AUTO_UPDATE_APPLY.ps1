param(
 [string]$ZipPath,
 [string]$InstallDir,
 [string]$Launcher,
 [string]$PythonExe,
 [string]$TargetVersion
)
$ErrorActionPreference="Stop"
$log=Join-Path $env:TEMP "SolinajEditor_Update.log"
function Log($m){ Add-Content -Path $log -Value ("[{0}] {1}" -f (Get-Date),$m) -Encoding UTF8 }
try {
 Start-Sleep -Seconds 2
 Log "Updater basladi. InstallDir=$InstallDir"
 $stamp=Get-Date -Format "yyyyMMdd_HHmmss"
 $backup=Join-Path $InstallDir ("_update_backup\"+$stamp)
 $temp=Join-Path $env:TEMP ("SolinajEditorUpdate_"+$stamp)
 New-Item -ItemType Directory -Force -Path $backup,$temp | Out-Null

 Get-ChildItem $InstallDir -Force | Where-Object {$_.Name -ne "_update_backup"} |
   ForEach-Object { Copy-Item $_.FullName $backup -Recurse -Force }

 $settings=Join-Path $InstallDir "config\settings.json"
 $settingsTemp=Join-Path $env:TEMP ("SolinajSettings_"+$stamp+".json")
 if(Test-Path $settings){ Copy-Item $settings $settingsTemp -Force }

 Expand-Archive $ZipPath $temp -Force
 $items=@(Get-ChildItem $temp -Force)
 $payload=$temp
 if($items.Count -eq 1 -and $items[0].PSIsContainer){ $payload=$items[0].FullName }
 Get-ChildItem $payload -Force | ForEach-Object { Copy-Item $_.FullName $InstallDir -Recurse -Force }

 if(Test-Path $settingsTemp){
   New-Item -ItemType Directory -Force -Path (Split-Path $settings) | Out-Null
   Copy-Item $settingsTemp $settings -Force
 }

 Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue
 Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue
 Log "Dosyalar uygulandi."

 $marker=Join-Path $InstallDir "update_success.json"
 $markerObj=@{
   version=$TargetVersion
   installed_at=(Get-Date).ToString("s")
   success=$true
 }
 $markerObj | ConvertTo-Json | Set-Content -Path $marker -Encoding UTF8
 Log "Basari isareti yazildi: $marker"

 $appPy=Join-Path $InstallDir "app.py"
 if($PythonExe -and (Test-Path $PythonExe)){
   Log "Program ayni Python ile aciliyor: $PythonExe"
   Start-Process -FilePath $PythonExe -ArgumentList ('"' + $appPy + '"') -WorkingDirectory $InstallDir
 } elseif(Test-Path $Launcher) {
   Log "Launcher ile aciliyor."
   Start-Process "$env:WINDIR\System32\wscript.exe" -ArgumentList ('"' + $Launcher + '"')
 } else {
   throw "Programi yeniden baslatacak Python/Launcher bulunamadi."
 }
 Log "Updater tamamlandi."
}
catch {
 Log ("HATA: "+$_.Exception.Message)
 try {
   if($backup -and (Test-Path $backup)){
     Log "Geri alma deneniyor."
     Get-ChildItem $backup -Force | ForEach-Object { Copy-Item $_.FullName $InstallDir -Recurse -Force }
   }
 } catch { Log ("GERI ALMA HATASI: "+$_.Exception.Message) }
 exit 1
}
