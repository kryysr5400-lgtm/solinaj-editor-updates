
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import threading, time
import os
import subprocess
import shutil
import webbrowser
import sys, json, urllib.request, tempfile, hashlib, re

from modules.ffmpeg_tools import find_ffmpeg, probe_duration, export_video
from modules.settings import load_settings, save_settings
from modules.versioning import APP_NAME, APP_VERSION, check_local_manifest

BG = "#0f1014"
PANEL = "#17181d"
PANEL2 = "#1d1f25"
BORDER = "#2a2d35"
TEXT = "#f4f6fa"
MUTED = "#9aa1ad"
ACCENT = "#38d9c5"
ACCENT_HOVER = "#2fc4b2"
BTN = "#282b33"
BTN_HOVER = "#343842"
TIMELINE_BG = "#111217"
TRACK = "#1c1f26"
CLIP = "#284b53"
AUDIO = "#34394a"
RED = "#ef5b64"


class SolinajEditor(tk.Tk):
    def __init__(self):
        super().__init__()
        self.music_library = []
        self.music_meta = {}
        self.sticker_library = []
        self.selected_music_path = ""
        self.music_preview_proc = None
        self._load_builtin_media_library()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self._solinaj_media_menu_added = True
        media_menu = tk.Menu(self)
        library_menu = tk.Menu(media_menu, tearoff=0)
        library_menu.add_command(label="🎵 Telifsiz Müzik", command=self.open_music_library)
        library_menu.add_command(label="😀 Emoji & Sticker", command=self.open_sticker_library)
        media_menu.add_cascade(label="Medya", menu=library_menu)
        self.config(menu=media_menu)
        self.geometry("1480x900")
        self.minsize(1180, 760)
        self.configure(bg=BG)

        self.settings = load_settings()
        self.media_files = []
        self.selected_media = None
        self.duration = 0.0

        self.input_path = tk.StringVar()
        self.output_path = tk.StringVar()
        self.start_time = tk.StringVar(value="00:00:00")
        self.end_time = tk.StringVar(value="")
        self.aspect = tk.StringVar(value="16:9 YouTube")
        self.speed = tk.DoubleVar(value=1.0)
        self.volume = tk.DoubleVar(value=1.0)
        self.music_volume = tk.DoubleVar(value=0.35)
        self.overlay_text = tk.StringVar(value="")
        self.logo_path = tk.StringVar(value="")
        self.status = tk.StringVar(value="Hazır")
        self.progress = tk.DoubleVar(value=0)
        self.playhead = tk.DoubleVar(value=0.0)
        self.timeline_zoom = tk.DoubleVar(value=1.0)

        # Gerçek önizleme oynatma durumu
        self.preview_playing = False
        self.preview_paused = False
        self.preview_video_proc = None
        self.preview_audio_proc = None
        self.preview_thread = None
        self.preview_generation = 0
        self._preview_photo = None

        self._style()
        self._build_ui()
        self._bind_shortcuts()
        self.after(300, self._startup_check)

    def _style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except Exception:
            pass
        s.configure("Treeview", background=PANEL2, fieldbackground=PANEL2, foreground=TEXT,
                    borderwidth=0, rowheight=30, font=("Segoe UI", 10))
        s.configure("Treeview.Heading", background=PANEL, foreground=MUTED, relief="flat",
                    font=("Segoe UI", 9, "bold"))
        s.map("Treeview", background=[("selected", "#2c3740")], foreground=[("selected", TEXT)])
        s.configure("TCombobox", fieldbackground=BTN, background=BTN, foreground=TEXT,
                    arrowcolor=TEXT, bordercolor=BORDER)
        s.configure("Horizontal.TProgressbar", troughcolor="#242730", background=ACCENT, bordercolor="#242730")
        s.configure("TPanedwindow", background=BG)

    def _button(self, parent, text, cmd=None, accent=False, width=None):
        bg = ACCENT if accent else BTN
        fg = "#07100f" if accent else TEXT
        b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                      activebackground=ACCENT_HOVER if accent else BTN_HOVER,
                      activeforeground=fg, relief="flat", bd=0,
                      font=("Segoe UI", 10, "bold" if accent else "normal"),
                      padx=14, pady=8, cursor="hand2", width=width)
        return b

    def _label(self, parent, text="", **kw):
        opts = dict(bg=PANEL, fg=TEXT, font=("Segoe UI", 10))
        opts.update(kw)
        return tk.Label(parent, text=text, **opts)

    def _build_ui(self):
        self._build_titlebar()
        self._build_main()
        self._build_statusbar()

    def _build_titlebar(self):
        bar = tk.Frame(self, bg="#14151a", height=58, highlightthickness=1, highlightbackground=BORDER)
        bar.pack(fill="x", side="top")
        bar.pack_propagate(False)

        left = tk.Frame(bar, bg="#14151a")
        left.pack(side="left", fill="y")
        tk.Label(left, text="◆", bg="#14151a", fg=ACCENT, font=("Segoe UI Symbol", 17, "bold")).pack(side="left", padx=(16,6))
        tk.Label(left, text="SOLINAJ EDITOR", bg="#14151a", fg=TEXT,
                 font=("Segoe UI", 15, "bold")).pack(side="left")
        tk.Label(left, text=f"  V{APP_VERSION}", bg="#14151a", fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left", pady=(4,0))

        center = tk.Frame(bar, bg="#14151a")
        center.pack(side="left", padx=40, fill="y")
        title_actions = [
            ("Dosya", self.import_media),
            ("Düzenle", self.split_clip),
            ("Görünüm", self._refresh_view),
            ("Yardım", self._show_help),
        ]
        for t, cmd in title_actions:
            tk.Button(center, text=t, command=cmd, bg="#14151a", fg=MUTED, activebackground="#202228",
                      activeforeground=TEXT, relief="flat", bd=0, font=("Segoe UI", 9),
                      padx=10, pady=17, cursor="hand2").pack(side="left")

        right = tk.Frame(bar, bg="#14151a")
        right.pack(side="right", padx=12, fill="y")
        self._button(right, "↻  Güncelle", self.check_update).pack(side="left", padx=5, pady=10)
        self._button(right, "DIŞA AKTAR", self.start_export, accent=True).pack(side="left", padx=5, pady=10)

    def _build_main(self):
        outer = tk.PanedWindow(self, orient="vertical", bg=BORDER, sashwidth=5,
                               bd=0, relief="flat", sashrelief="flat")
        outer.pack(fill="both", expand=True)

        work = tk.Frame(outer, bg=BG)
        timeline = tk.Frame(outer, bg=TIMELINE_BG, height=285)
        outer.add(work, stretch="always", minsize=420)
        outer.add(timeline, stretch="never", minsize=230)

        main = tk.PanedWindow(work, orient="horizontal", bg=BORDER, sashwidth=5, bd=0)
        main.pack(fill="both", expand=True)

        media = tk.Frame(main, bg=PANEL, width=280)
        preview = tk.Frame(main, bg="#0b0c10", width=760)
        inspector = tk.Frame(main, bg=PANEL, width=330)
        main.add(media, minsize=230)
        main.add(preview, minsize=520)
        main.add(inspector, minsize=290)

        self._build_media_panel(media)
        self._build_preview(preview)
        self._build_inspector(inspector)
        self._build_timeline(timeline)

    def _build_media_panel(self, parent):
        hdr = tk.Frame(parent, bg=PANEL)
        hdr.pack(fill="x", padx=12, pady=(12,8))
        tk.Label(hdr, text="Medya", bg=PANEL, fg=TEXT, font=("Segoe UI", 12, "bold")).pack(side="left")
        self._button(hdr, "+ İçe Aktar", self.import_media, accent=True).pack(side="right")

        tabs = tk.Frame(parent, bg=PANEL)
        tabs.pack(fill="x", padx=12)
        tab_actions = [
            ("Yerel", lambda: self.status.set("Yerel medya")),
            ("Ses", self.open_music_library),
            ("Metin", self._focus_text_overlay),
            ("Geçiş", lambda: self.status.set("Geçişler sonraki sürüm için hazırlanıyor.")),
            ("Efekt", lambda: self.status.set("Efektler sonraki sürüm için hazırlanıyor.")),
        ]
        for i, (t, cmd) in enumerate(tab_actions):
            fg = TEXT if i == 0 else MUTED
            tk.Button(tabs, text=t, command=cmd, bg=PANEL, fg=fg, activebackground=BTN,
                      activeforeground=TEXT, relief="flat", bd=0,
                      font=("Segoe UI", 9, "bold" if i==0 else "normal"),
                      padx=7, pady=7, cursor="hand2").pack(side="left")
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x")

        search = tk.Entry(parent, bg="#111319", fg=TEXT, insertbackground=TEXT, relief="flat",
                          font=("Segoe UI", 10))
        search.insert(0, "  Medyada ara")
        search.pack(fill="x", padx=12, pady=12, ipady=7)

        self.media_tree = ttk.Treeview(parent, columns=("type","dur"), show="headings", selectmode="browse")
        self.media_tree.heading("type", text="DOSYA")
        self.media_tree.heading("dur", text="SÜRE")
        self.media_tree.column("type", width=175, stretch=True)
        self.media_tree.column("dur", width=60, anchor="e", stretch=False)
        self.media_tree.pack(fill="both", expand=True, padx=12, pady=(0,12))
        self.media_tree.bind("<<TreeviewSelect>>", self._media_selected)
        self.media_tree.bind("<Double-1>", lambda e: self.add_selected_to_timeline())

        foot = tk.Frame(parent, bg=PANEL)
        foot.pack(fill="x", padx=12, pady=(0,12))
        self._button(foot, "＋ Timeline'a Ekle", self.add_selected_to_timeline).pack(fill="x")

    def _build_preview(self, parent):
        top = tk.Frame(parent, bg="#0b0c10")
        top.pack(fill="x", padx=12, pady=10)
        tk.Label(top, text="Player", bg="#0b0c10", fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        self.preview_format = tk.Label(top, text="16:9", bg="#0b0c10", fg=MUTED, font=("Segoe UI", 9))
        self.preview_format.pack(side="right")

        stage_wrap = tk.Frame(parent, bg="#0b0c10")
        stage_wrap.pack(fill="both", expand=True, padx=18, pady=(0,6))
        self.stage = tk.Canvas(stage_wrap, bg="#050608", highlightthickness=1, highlightbackground="#202229")
        self.stage.pack(fill="both", expand=True)
        self.stage.bind("<Configure>", self._draw_preview_placeholder)

        controls = tk.Frame(parent, bg="#0b0c10")
        controls.pack(fill="x", padx=18, pady=(0,10))
        self.time_lbl = tk.Label(controls, text="00:00:00 / 00:00:00", bg="#0b0c10",
                                 fg=MUTED, font=("Consolas", 9))
        self.time_lbl.pack(side="left")
        center = tk.Frame(controls, bg="#0b0c10")
        center.place(relx=.5, rely=.5, anchor="center")
        buttons = [
            ("⏮", lambda: self._seek(0)),
            ("◀ 5s", lambda: self._step(-5)),
        ]
        for bt, cmd in buttons:
            tk.Button(center, text=bt, command=cmd, bg="#0b0c10", fg=TEXT,
                      activebackground="#191b21", activeforeground=TEXT,
                      relief="flat", bd=0, padx=7, pady=4, cursor="hand2").pack(side="left")
        self.play_button = tk.Button(center, text="▶", command=self.toggle_preview, bg="#0b0c10", fg=TEXT,
                                     activebackground="#191b21", activeforeground=TEXT,
                                     relief="flat", bd=0, padx=10, pady=4, cursor="hand2")
        self.play_button.pack(side="left")
        tk.Button(center, text="⏹", command=self.stop_preview, bg="#0b0c10", fg=TEXT,
                  activebackground="#191b21", activeforeground=TEXT,
                  relief="flat", bd=0, padx=7, pady=4, cursor="hand2").pack(side="left")
        tk.Button(center, text="5s ▶", command=lambda: self._step(5), bg="#0b0c10", fg=TEXT,
                  activebackground="#191b21", activeforeground=TEXT,
                  relief="flat", bd=0, padx=7, pady=4, cursor="hand2").pack(side="left")
        tk.Button(center, text="⏭", command=lambda: self._seek(self.duration), bg="#0b0c10", fg=TEXT,
                  activebackground="#191b21", activeforeground=TEXT,
                  relief="flat", bd=0, padx=7, pady=4, cursor="hand2").pack(side="left")
        tk.Label(controls, text="100%", bg="#0b0c10", fg=MUTED, font=("Segoe UI", 9)).pack(side="right")

    def _build_inspector(self, parent):
        hdr = tk.Frame(parent, bg=PANEL)
        hdr.pack(fill="x", padx=14, pady=(13,9))
        tk.Label(hdr, text="Özellikler", bg=PANEL, fg=TEXT, font=("Segoe UI", 12, "bold")).pack(side="left")
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x")

        canvas = tk.Canvas(parent, bg=PANEL, highlightthickness=0)
        scroll = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=PANEL)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=inner, anchor="nw", width=310)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self._inspector_section(inner, "Temel")
        self._combo(inner, "Tuval / Format", self.aspect,
                    ["Orijinal", "16:9 YouTube", "9:16 Shorts", "1:1 Kare"],
                    callback=self._format_changed)
        self._entry(inner, "Başlangıç", self.start_time)
        self._entry(inner, "Bitiş", self.end_time)

        self._inspector_section(inner, "Video")
        self._scale(inner, "Hız", self.speed, 0.5, 2.0, suffix="x")
        self._scale(inner, "Ses", self.volume, 0.0, 2.0, suffix="x")

        self._inspector_section(inner, "Müzik")
        self._scale(inner, "Müzik Ses Seviyesi", self.music_volume, 0.0, 1.0, suffix="x")
        self._button(inner, "🎵 Ses / Müzikni Aç", self.open_music_library).pack(fill="x", padx=14, pady=(0,10))

        self._inspector_section(inner, "Metin")
        self._entry(inner, "Ekran Yazısı", self.overlay_text)

        self._inspector_section(inner, "Logo / Filigran")
        lr = tk.Frame(inner, bg=PANEL)
        lr.pack(fill="x", padx=14, pady=(4,10))
        tk.Entry(lr, textvariable=self.logo_path, bg="#111319", fg=TEXT, insertbackground=TEXT,
                 relief="flat", font=("Segoe UI", 9)).pack(side="left", fill="x", expand=True, ipady=7)
        self._button(lr, "Seç", self.pick_logo).pack(side="left", padx=(6,0))

        self._inspector_section(inner, "Çıktı")
        self._entry(inner, "Kayıt Yolu", self.output_path)
        self._button(inner, "Kaydetme Yerini Seç", self.pick_output).pack(fill="x", padx=14, pady=(0,10))

    def _inspector_section(self, parent, title):
        tk.Label(parent, text=title, bg=PANEL, fg=TEXT, font=("Segoe UI", 10, "bold"),
                 anchor="w").pack(fill="x", padx=14, pady=(14,5))

    def _entry(self, parent, label, var):
        tk.Label(parent, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=14)
        tk.Entry(parent, textvariable=var, bg="#111319", fg=TEXT, insertbackground=TEXT, relief="flat",
                 font=("Segoe UI", 9)).pack(fill="x", padx=14, pady=(3,8), ipady=7)

    def _combo(self, parent, label, var, values, callback=None):
        tk.Label(parent, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=14)
        cb = ttk.Combobox(parent, textvariable=var, values=values, state="readonly")
        cb.pack(fill="x", padx=14, pady=(3,8))
        if callback:
            cb.bind("<<ComboboxSelected>>", lambda e: callback())

    def _scale(self, parent, label, var, mn, mx, suffix=""):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", padx=14)
        tk.Label(row, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        val = tk.Label(row, text="", bg=PANEL, fg=TEXT, font=("Segoe UI", 9))
        val.pack(side="right")
        def refresh(*_):
            val.config(text=f"{var.get():.2f}{suffix}")
        var.trace_add("write", refresh)
        refresh()
        tk.Scale(parent, variable=var, from_=mn, to=mx, resolution=.05, orient="horizontal",
                 bg=PANEL, fg=TEXT, troughcolor="#2a2d35", activebackground=ACCENT,
                 highlightthickness=0, bd=0, showvalue=False).pack(fill="x", padx=14, pady=(0,8))

    def _build_timeline(self, parent):
        tool = tk.Frame(parent, bg="#17191f", height=44)
        tool.pack(fill="x")
        tool.pack_propagate(False)
        left = tk.Frame(tool, bg="#17191f")
        left.pack(side="left", padx=10)
        for t, cmd in [("✂ Böl", self.split_clip), ("🗑 Sil", self.remove_clip),
                       ("↶ Geri", lambda: self.status.set("Geri alma: V2 arayüz altyapısı hazır")),
                       ("↷ İleri", lambda: self.status.set("İleri alma: V2 arayüz altyapısı hazır"))]:
            self._button(left, t, cmd).pack(side="left", padx=3, pady=6)

        right = tk.Frame(tool, bg="#17191f")
        right.pack(side="right", padx=10)
        tk.Label(right, text="Timeline", bg="#17191f", fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        tk.Scale(right, variable=self.timeline_zoom, from_=0.5, to=3.0, resolution=.1,
                 orient="horizontal", bg="#17191f", fg=TEXT, troughcolor="#2a2d35",
                 highlightthickness=0, bd=0, showvalue=False,
                 command=lambda x:self._draw_timeline()).pack(side="left", padx=8)

        self.timeline = tk.Canvas(parent, bg=TIMELINE_BG, highlightthickness=0)
        self.timeline.pack(fill="both", expand=True)
        self.timeline.bind("<Configure>", lambda e:self._draw_timeline())
        self.timeline.bind("<Button-1>", self._timeline_click)

    def _build_statusbar(self):
        bar = tk.Frame(self, bg="#14151a", height=34, highlightthickness=1, highlightbackground=BORDER)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        tk.Label(bar, textvariable=self.status, bg="#14151a", fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left", padx=12)
        ttk.Progressbar(bar, variable=self.progress, maximum=100, style="Horizontal.TProgressbar",
                        length=220).pack(side="right", padx=12, pady=9)

    def _draw_preview_placeholder(self, event=None):
        if getattr(self, "preview_playing", False):
            return
        c = self.stage
        c.delete("all")
        self._preview_photo = None
        w, h = max(1, c.winfo_width()), max(1, c.winfo_height())
        if self.aspect.get() == "9:16 Shorts":
            rw = min(w*.48, h*9/16)
            rh = rw*16/9
        elif self.aspect.get() == "1:1 Kare":
            rw = rh = min(w*.72, h*.72)
        else:
            rw = min(w*.86, h*16/9)
            rh = rw*9/16
        x1, y1 = (w-rw)/2, (h-rh)/2
        x2, y2 = x1+rw, y1+rh
        c.create_rectangle(x1, y1, x2, y2, fill="#08090c", outline="#343741")
        if self.selected_media:
            c.create_text(w/2, h/2-16, text=Path(self.selected_media).name,
                          fill=TEXT, font=("Segoe UI", 14, "bold"), width=max(200,int(rw*.75)))
            c.create_text(w/2, h/2+18, text="▶  Oynat düğmesiyle burada önizle",
                          fill=MUTED, font=("Segoe UI", 9))
        else:
            c.create_text(w/2, h/2-12, text="MEDYA İÇE AKTAR",
                          fill=TEXT, font=("Segoe UI", 18, "bold"))
            c.create_text(w/2, h/2+20, text="Videonu sol panelden ekle ve timeline'a gönder",
                          fill=MUTED, font=("Segoe UI", 10))

    def _draw_timeline(self):
        c = self.timeline
        c.delete("all")
        w, h = max(1,c.winfo_width()), max(1,c.winfo_height())
        label_w = 105
        ruler_h = 28
        track_h = 52
        c.create_rectangle(0,0,w,h,fill=TIMELINE_BG,outline="")
        c.create_rectangle(0,0,w,ruler_h,fill="#17191f",outline="")
        c.create_text(12, ruler_h/2, text="00:00", fill=MUTED, anchor="w", font=("Consolas",8))

        dur = max(60.0, self.duration or 60.0)
        px_per_sec = max(2.0, (w-label_w)/dur) * self.timeline_zoom.get()
        major = 10 if px_per_sec < 8 else 5
        t = 0
        while t <= dur:
            x = label_w + t*px_per_sec
            if x > w: break
            c.create_line(x, 20, x, ruler_h, fill="#4a4d57")
            c.create_text(x+2, 8, text=self._fmt_short(t), fill=MUTED, anchor="nw", font=("Consolas",7))
            t += major

        tracks = [("V1  Video", TRACK), ("V2  Overlay", TRACK), ("A1  Ses", TRACK)]
        for i,(name,bg) in enumerate(tracks):
            y1 = ruler_h + i*track_h
            y2 = y1 + track_h - 2
            c.create_rectangle(0,y1,label_w-2,y2,fill="#17191f",outline="")
            c.create_text(12,(y1+y2)/2,text=name,fill=MUTED,anchor="w",font=("Segoe UI",8,"bold"))
            c.create_rectangle(label_w,y1,w,y2,fill=bg,outline="")

        if self.selected_media:
            clip_dur = self.duration or 30
            clip_w = min(w-label_w-12, max(140, clip_dur*px_per_sec))
            y1 = ruler_h+4
            y2 = ruler_h+track_h-6
            c.create_rectangle(label_w+4,y1,label_w+clip_w,y2,fill=CLIP,outline=ACCENT,width=1,tags=("clip",))
            c.create_text(label_w+12,(y1+y2)/2,text=Path(self.selected_media).name,
                          fill=TEXT,anchor="w",font=("Segoe UI",8,"bold"),width=max(80,int(clip_w-30)),tags=("clip",))
            # audio representation
            ay1 = ruler_h + 2*track_h + 4
            ay2 = ay1 + track_h - 10
            c.create_rectangle(label_w+4,ay1,label_w+clip_w,ay2,fill=AUDIO,outline="#62687a",tags=("clip",))
            # fake waveform
            x = label_w+12
            mid=(ay1+ay2)/2
            while x < label_w+clip_w-8:
                amp = 5 + int((x*7)%13)
                c.create_line(x,mid-amp,x,mid+amp,fill="#8e96ad")
                x += 7

        # playhead
        play_x = label_w + self.playhead.get()*px_per_sec
        play_x = min(max(label_w, play_x), w)
        c.create_line(play_x,0,play_x,h,fill=RED,width=2)
        c.create_polygon(play_x-5,0,play_x+5,0,play_x,7,fill=RED,outline="")

    def import_media(self):
        paths = filedialog.askopenfilenames(
            title="Medya içe aktar",
            filetypes=[("Medya", "*.mp4 *.mkv *.mov *.avi *.webm *.mp3 *.wav *.m4a"),
                       ("Tüm dosyalar","*.*")]
        )
        for p in paths:
            if p not in self.media_files:
                self.media_files.append(p)
                dur = probe_duration(p) if Path(p).suffix.lower() not in {".mp3",".wav",".m4a"} else None
                self.media_tree.insert("", "end", iid=str(len(self.media_files)-1),
                                       values=(Path(p).name, self._fmt_short(dur) if dur else "—"))
        if paths and self.selected_media is None:
            first = str(len(self.media_files)-len(paths))
            try:
                self.media_tree.selection_set(first)
                self._select_media_path(self.media_files[int(first)])
            except Exception:
                pass

    def _media_selected(self, event=None):
        sel = self.media_tree.selection()
        if not sel:
            return
        try:
            p = self.media_files[int(sel[0])]
        except Exception:
            return
        self._select_media_path(p)

    def _select_media_path(self, p):
        self.selected_media = p
        self.input_path.set(p)
        try:
            self.duration = probe_duration(p) or 0
        except Exception:
            self.duration = 0
        self.start_time.set("00:00:00")
        if self.duration:
            self.end_time.set(self._fmt(self.duration))
        pp = Path(p)
        self.output_path.set(str(pp.with_name(pp.stem + "_solinaj_edit.mp4")))
        self.playhead.set(0)
        self.time_lbl.config(text=f"00:00:00 / {self._fmt(self.duration)}")
        self.status.set(f"Seçildi: {pp.name}")
        self._draw_preview_placeholder()
        self._draw_timeline()

    def add_selected_to_timeline(self):
        if not self.selected_media:
            messagebox.showinfo("Timeline", "Önce soldan bir medya seç.")
            return
        self.status.set(f"Timeline'a eklendi: {Path(self.selected_media).name}")
        self._draw_timeline()

    def _timeline_click(self, e):
        label_w=105
        if e.x < label_w:
            return
        w=max(1,self.timeline.winfo_width())
        dur=max(60.0,self.duration or 60.0)
        px=max(2.0,(w-label_w)/dur)*self.timeline_zoom.get()
        sec=max(0,(e.x-label_w)/px)
        if self.duration:
            sec=min(sec,self.duration)
        self._seek(sec)

    def _seek(self, sec):
        sec = float(sec or 0)
        if self.duration:
            sec = max(0.0, min(sec, self.duration))
        else:
            sec = max(0.0, sec)
        self.playhead.set(sec)
        self.time_lbl.config(text=f"{self._fmt(self.playhead.get())} / {self._fmt(self.duration)}")
        self._draw_timeline()
        if self.preview_playing:
            self._start_preview_from(sec)

    def _step(self, delta):
        self._seek(max(0, min(self.duration or 999999, self.playhead.get()+delta)))

    def split_clip(self):
        if not self.selected_media:
            messagebox.showinfo("Böl", "Önce bir video seç.")
            return
        t = self.playhead.get()
        self.start_time.set(self._fmt(t))
        self.status.set(f"Kesme noktası ayarlandı: {self._fmt(t)}")

    def remove_clip(self):
        if not self.selected_media:
            messagebox.showinfo("Sil", "Timeline'da seçili video yok.")
            return
        self.stop_preview(reset=True)
        self.status.set("Timeline görünümünden klip kaldırıldı (dosya silinmedi).")
        self.selected_media=None
        self.input_path.set("")
        self.duration=0
        self.playhead.set(0)
        self._draw_preview_placeholder()
        self._draw_timeline()

    def _preview_open(self):
        # Eski Windows oynatıcısı davranışı yerine gerçek uygulama içi önizleme.
        self.toggle_preview()

    def toggle_preview(self):
        if not self.selected_media or not Path(self.selected_media).exists():
            messagebox.showinfo("Player", "Önce bir video seç.")
            return
        if self.preview_playing:
            self.pause_preview()
        else:
            self._start_preview_from(self.playhead.get())

    def pause_preview(self):
        if not self.preview_playing:
            return
        self._stop_preview_processes()
        self.preview_playing = False
        self.preview_paused = True
        if hasattr(self, "play_button"):
            self.play_button.config(text="▶")
        self.status.set(f"Player duraklatıldı • {self._fmt(self.playhead.get())}")

    def stop_preview(self, reset=False):
        self._stop_preview_processes()
        self.preview_playing = False
        self.preview_paused = False
        if reset:
            self.playhead.set(0)
        if hasattr(self, "play_button"):
            self.play_button.config(text="▶")
        self.time_lbl.config(text=f"{self._fmt(self.playhead.get())} / {self._fmt(self.duration)}")
        self._draw_preview_placeholder()
        self._draw_timeline()
        self.status.set("Player durduruldu.")

    def _stop_preview_processes(self):
        self.preview_generation += 1
        for proc_name in ("preview_video_proc", "preview_audio_proc"):
            proc = getattr(self, proc_name, None)
            if proc is not None:
                try:
                    if proc.poll() is None:
                        proc.terminate()
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass
                setattr(self, proc_name, None)

    def _find_ffplay(self):
        candidates = [
            shutil.which("ffplay"),
            str(Path(__file__).resolve().parent / "ffmpeg" / "bin" / "ffplay.exe"),
        ]
        for p in candidates:
            if p and Path(p).exists():
                return p
        return None

    def _start_preview_from(self, start_sec):
        ffmpeg = find_ffmpeg()
        if not ffmpeg:
            messagebox.showerror("Player", "FFmpeg bulunamadı. V2.2.6 FFmpeg onarım paketini yeniden çalıştır.")
            return
        self._stop_preview_processes()
        self.preview_generation += 1
        generation = self.preview_generation
        start_sec = max(0.0, float(start_sec or 0))
        self.playhead.set(start_sec)

        # Görüntüyü PPM kareleri olarak doğrudan Tkinter Canvas'a aktar.
        cmd = [
            ffmpeg, "-hide_banner", "-loglevel", "error",
            "-ss", str(start_sec), "-re", "-i", self.selected_media,
            "-an",
            "-vf", "scale=854:480:force_original_aspect_ratio=decrease,pad=854:480:(ow-iw)/2:(oh-ih)/2,fps=20",
            "-f", "image2pipe", "-vcodec", "ppm", "pipe:1"
        ]
        try:
            self.preview_video_proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
        except Exception as e:
            messagebox.showerror("Player", str(e))
            return

        # FFplay varsa sesi görünmez biçimde eş zamanlı başlat.
        ffplay = self._find_ffplay()
        if ffplay:
            try:
                self.preview_audio_proc = subprocess.Popen(
                    [ffplay, "-nodisp", "-autoexit", "-loglevel", "quiet",
                     "-ss", str(start_sec), self.selected_media],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
                )
            except Exception:
                self.preview_audio_proc = None

        self.preview_playing = True
        self.preview_paused = False
        if hasattr(self, "play_button"):
            self.play_button.config(text="⏸")
        self.status.set("Player oynatılıyor..." + ("" if ffplay else " • Ses önizlemesi için ffplay bulunamadı"))
        self.preview_thread = threading.Thread(
            target=self._preview_reader, args=(self.preview_video_proc, generation, start_sec), daemon=True
        )
        self.preview_thread.start()

    def _preview_reader(self, proc, generation, start_sec):
        stream = proc.stdout
        frame_index = 0
        fps = 20.0
        try:
            while stream and generation == self.preview_generation:
                magic = stream.readline()
                if not magic:
                    break
                if magic.strip() != b"P6":
                    continue
                size_line = stream.readline()
                while size_line.startswith(b"#"):
                    size_line = stream.readline()
                try:
                    width, height = [int(x) for x in size_line.strip().split()]
                except Exception:
                    break
                maxv = stream.readline()
                if not maxv:
                    break
                need = width * height * 3
                data = bytearray()
                while len(data) < need:
                    chunk = stream.read(need - len(data))
                    if not chunk:
                        break
                    data.extend(chunk)
                if len(data) != need:
                    break
                ppm = b"P6\n%d %d\n255\n" % (width, height) + bytes(data)
                current = start_sec + frame_index / fps
                frame_index += 1
                self.after(0, lambda d=ppm, t=current, g=generation: self._show_preview_frame(d, t, g))
        except Exception:
            pass
        finally:
            if generation == self.preview_generation:
                self.after(0, lambda g=generation: self._preview_finished(g))

    def _show_preview_frame(self, ppm_data, current, generation):
        if generation != self.preview_generation or not self.preview_playing:
            return
        try:
            photo = tk.PhotoImage(data=ppm_data, format="PPM")
            self._preview_photo = photo
            c = self.stage
            c.delete("all")
            c.create_image(c.winfo_width()/2, c.winfo_height()/2, image=photo, anchor="center")
            self.playhead.set(current)
            self.time_lbl.config(text=f"{self._fmt(current)} / {self._fmt(self.duration)}")
            self._draw_timeline()
        except Exception as e:
            self.status.set(f"Player kare hatası: {e}")

    def _preview_finished(self, generation):
        if generation != self.preview_generation:
            return
        self.preview_playing = False
        if hasattr(self, "play_button"):
            self.play_button.config(text="▶")
        if self.duration and self.playhead.get() >= self.duration - 0.2:
            self.playhead.set(self.duration)
        self.status.set("Player tamamlandı.")

    def _refresh_view(self):
        self._draw_preview_placeholder()
        self._draw_timeline()
        self.status.set("Görünüm yenilendi.")

    def _show_help(self):
        messagebox.showinfo(
            "Solinaj Editor Yardım",
            "V2.2 Kontrolleri\n\n"
            "• + İçe Aktar: video seç\n"
            "• ▶ / ⏸: uygulama içinde oynat/duraklat\n"
            "• ⏹: durdur\n"
            "• ◀ 5s / 5s ▶: geri/ileri sar\n"
            "• Timeline'a tıklayarak konuma git\n"
            "• Ctrl+O: içe aktar, Space: oynat/duraklat, Ctrl+E: dışa aktar"
        )

    def _focus_text_overlay(self):
        self.status.set("Metin aracını sağdaki 'Ekran Yazısı' alanından düzenleyebilirsin.")

    def _format_changed(self):
        fmt = self.aspect.get()
        self.preview_format.config(text="9:16" if "9:16" in fmt else "1:1" if "1:1" in fmt else "16:9")
        self._draw_preview_placeholder()

    def pick_output(self):
        p = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4","*.mp4")])
        if p:
            self.output_path.set(p)

    def pick_logo(self):
        p = filedialog.askopenfilename(filetypes=[("Görsel","*.png *.jpg *.jpeg *.webp")])
        if p:
            self.logo_path.set(p)


    def _load_builtin_media_library(self):
        """Solinaj'ın dahili ve kullanıcının eklediği medya kütüphanesini yükler."""
        base = Path(__file__).resolve().parent
        lib = base / "media_library"
        music = lib / "music"
        stickers = lib / "stickers"
        music.mkdir(parents=True, exist_ok=True)
        stickers.mkdir(parents=True, exist_ok=True)
        self.music_library = sorted([p for p in music.rglob("*") if p.suffix.lower() in {".mp3",".wav",".m4a",".aac",".ogg"}], key=lambda p:p.name.lower())
        self.music_meta = {}
        for mf in music.rglob("library.json"):
            try:
                data=json.loads(mf.read_text(encoding="utf-8-sig"))
                for item in data.get("tracks",[]):
                    self.music_meta[item.get("file","")] = item
            except Exception:
                pass
        self.sticker_library = [p for p in stickers.rglob("*") if p.suffix.lower() in {".png",".webp",".jpg",".jpeg"}]

    def open_music_library(self):
        win = tk.Toplevel(self)
        win.title("🎵 Solinaj Ses / Müzik")
        win.geometry("900x610")
        win.configure(bg="#15171b")
        tk.Label(win,text="🎵 SOLINAJ MÜZİK KÜTÜPHANESİ",font=("Segoe UI",18,"bold"),fg="white",bg="#15171b").pack(pady=(18,4))
        tk.Label(win,text="Uygulamayla gelen Solinaj Original parçaları + kendi eklediğin müzikler.",font=("Segoe UI",10),fg="#aeb4bf",bg="#15171b").pack()

        top=tk.Frame(win,bg="#15171b"); top.pack(fill="x",padx=18,pady=14)
        tk.Label(top,text="Kategori:",fg="white",bg="#15171b").pack(side="left")
        cat=tk.StringVar(value="Tümü")
        cats=["Tümü","Enerjik","Gerilim","Savaş","Komik","Chill","Sinematik","Oyun","Kullanıcı"]
        cb=ttk.Combobox(top,textvariable=cat,values=cats,state="readonly",width=16)
        cb.pack(side="left",padx=(8,14))
        tk.Button(top,text="＋ Kendi Müziğini Ekle",command=lambda:self._add_music_files(lst,cat),padx=12,pady=7).pack(side="left",padx=4)
        tk.Button(top,text="▶ Ön Dinle",command=lambda:self._preview_selected_music(lst),padx=12,pady=7).pack(side="left",padx=4)
        tk.Button(top,text="■ Durdur",command=self._stop_music_preview,padx=12,pady=7).pack(side="left",padx=4)

        list_frame=tk.Frame(win,bg="#15171b"); list_frame.pack(fill="both",expand=True,padx=18,pady=(0,8))
        lst=tk.Listbox(list_frame,bg="#202329",fg="white",selectbackground="#3a404a",font=("Segoe UI",11),activestyle="none")
        scr=ttk.Scrollbar(list_frame,orient="vertical",command=lst.yview); lst.configure(yscrollcommand=scr.set)
        lst.pack(side="left",fill="both",expand=True); scr.pack(side="right",fill="y")

        info=tk.StringVar(value="Bir parça seç. Dahili parçalar Solinaj için oluşturulmuş telifsiz örnek müziklerdir.")
        tk.Label(win,textvariable=info,fg="#aeb4bf",bg="#15171b",anchor="w").pack(fill="x",padx=18,pady=(0,8))

        foot=tk.Frame(win,bg="#15171b"); foot.pack(fill="x",padx=18,pady=(0,16))
        tk.Button(foot,text="➕ Timeline A1'e Ekle",command=lambda:self._use_selected_music(lst),padx=14,pady=8).pack(side="left")
        tk.Button(foot,text="🗑 Seçili Kullanıcı Müziğini Sil",command=lambda:self._delete_user_music(lst,cat),padx=12,pady=8).pack(side="left",padx=8)
        tk.Label(foot,text="Dahili Solinaj parçaları silinmez.",fg="#f0c674",bg="#15171b").pack(side="right")

        def refresh(*_):
            self._refresh_music_list(lst,cat.get())
        cb.bind("<<ComboboxSelected>>", refresh)
        def selected(_=None):
            sel=lst.curselection()
            if not sel: return
            p=getattr(lst,"_solinaj_paths",[])[sel[0]]
            meta=self.music_meta.get(p.name,{})
            info.set(f"{meta.get('title',p.stem)} • {meta.get('category','Kullanıcı')} • {meta.get('license','Kullanıcının eklediği dosya')}")
        lst.bind("<<ListboxSelect>>", selected)
        lst.bind("<Double-Button-1>", lambda e:self._preview_selected_music(lst))
        refresh()
        win.protocol("WM_DELETE_WINDOW", lambda:(self._stop_music_preview(),win.destroy()))

    def _music_category(self,p):
        meta=self.music_meta.get(p.name)
        if meta: return meta.get("category","Solinaj")
        if "Solinaj_Dahili" in p.parts: return "Solinaj"
        return "Kullanıcı"

    def _refresh_music_list(self, lst, category="Tümü"):
        self._load_builtin_media_library()
        lst.delete(0,"end")
        paths=[]
        for p in self.music_library:
            cat=self._music_category(p)
            if category != "Tümü" and cat != category:
                continue
            meta=self.music_meta.get(p.name,{})
            title=meta.get("title",p.stem.replace("__"," - "))
            lst.insert("end", f"{cat:10}  |  {title}")
            paths.append(p)
        lst._solinaj_paths=paths

    def _add_music_files(self, lst, cat_var=None):
        files=filedialog.askopenfilenames(title="Müzik seç",filetypes=[("Ses dosyaları","*.mp3 *.wav *.m4a *.aac *.ogg"),("Tüm dosyalar","*.*")])
        if not files: return
        dest=Path(__file__).resolve().parent/"media_library"/"music"/"Kullanici"
        dest.mkdir(parents=True,exist_ok=True)
        for f in files:
            src=Path(f); target=dest/src.name
            n=2
            while target.exists():
                target=dest/f"{src.stem}_{n}{src.suffix}"; n+=1
            shutil.copy2(src,target)
        if cat_var is not None: cat_var.set("Kullanıcı")
        self._refresh_music_list(lst,"Kullanıcı")
        self.status.set(f"{len(files)} müzik kütüphaneye eklendi.")

    def _preview_selected_music(self,lst):
        sel=lst.curselection()
        if not sel:
            messagebox.showwarning("Müzik","Önce bir müzik seç.")
            return
        paths=getattr(lst,"_solinaj_paths",[])
        if sel[0] >= len(paths): return
        p=paths[sel[0]]
        ffplay=self._find_ffplay()
        if not ffplay:
            messagebox.showerror("Müzik Player","FFplay bulunamadı. V2.2.6 FFmpeg paketinin kurulu olması gerekiyor.")
            return
        self._stop_music_preview()
        flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
        self.music_preview_proc=subprocess.Popen([ffplay,"-nodisp","-autoexit","-loglevel","quiet",str(p)],creationflags=flags)
        self.status.set("Müzik önizleme: "+p.name)

    def _stop_music_preview(self):
        p=getattr(self,"music_preview_proc",None)
        if p and p.poll() is None:
            try: p.terminate()
            except Exception: pass
        self.music_preview_proc=None

    def _use_selected_music(self, lst):
        sel=lst.curselection()
        if not sel:
            messagebox.showwarning("Müzik","Önce bir müzik seç.")
            return
        paths=getattr(lst,"_solinaj_paths",[])
        if sel[0] >= len(paths): return
        p=paths[sel[0]]
        self.selected_music_path=str(p)
        self.status.set("A1 müzik seçildi: "+p.name)
        self._draw_timeline()
        messagebox.showinfo("Müzik",f"{p.name}\n\nA1 müzik katmanına eklendi. Dışa aktarırken videonun sesiyle karıştırılacak.")

    def _delete_user_music(self,lst,cat_var):
        sel=lst.curselection()
        if not sel:
            messagebox.showwarning("Müzik","Önce bir müzik seç.")
            return
        paths=getattr(lst,"_solinaj_paths",[])
        p=paths[sel[0]]
        if "Solinaj_Dahili" in p.parts:
            messagebox.showinfo("Müzik","Dahili Solinaj parçaları korunur ve silinmez.")
            return
        if messagebox.askyesno("Müzik","Seçili müzik kütüphaneden silinsin mi?"):
            try:
                if self.selected_music_path == str(p): self.selected_music_path=""
                p.unlink()
                self._refresh_music_list(lst,cat_var.get())
            except Exception as e:
                messagebox.showerror("Müzik",str(e))

    def open_sticker_library(self):
        win=tk.Toplevel(self)
        win.title("😀 Emoji & Sticker Kütüphanesi")
        win.geometry("720x500")
        win.configure(bg="#15171b")
        tk.Label(win,text="😀 EMOJİ & STICKER",font=("Segoe UI",18,"bold"),fg="white",bg="#15171b").pack(pady=(18,4))
        tk.Label(win,text="PNG / WEBP görsellerini ekle ve video overlay'i olarak kullan.",font=("Segoe UI",10),fg="#aeb4bf",bg="#15171b").pack()
        bar=tk.Frame(win,bg="#15171b"); bar.pack(fill="x",padx=18,pady=14)
        tk.Button(bar,text="＋ Sticker / Emoji Ekle",command=lambda:self._add_sticker_files(lst),padx=12,pady=7).pack(side="left")
        lst=tk.Listbox(win,bg="#202329",fg="white",selectbackground="#3a404a",font=("Segoe UI",10))
        lst.pack(fill="both",expand=True,padx=18,pady=(0,10))
        self._refresh_sticker_list(lst)
        tk.Button(win,text="Videoya Overlay Olarak Seç",command=lambda:self._use_selected_sticker(lst),padx=12,pady=7).pack(pady=(0,16))

    def _refresh_sticker_list(self,lst):
        self._load_builtin_media_library()
        lst.delete(0,"end")
        for p in self.sticker_library: lst.insert("end",p.name)

    def _add_sticker_files(self,lst):
        files=filedialog.askopenfilenames(title="Sticker/emoji seç",filetypes=[("Görseller","*.png *.webp *.jpg *.jpeg"),("Tüm dosyalar","*.*")])
        if not files:return
        dest=Path(__file__).resolve().parent/"media_library"/"stickers"
        for f in files:
            src=Path(f); target=dest/src.name
            if target.exists(): target=dest/(src.stem+"_2"+src.suffix)
            shutil.copy2(src,target)
        self._refresh_sticker_list(lst)

    def _use_selected_sticker(self,lst):
        sel=lst.curselection()
        if not sel:
            messagebox.showwarning("Sticker","Önce bir sticker seç.")
            return
        p=self.sticker_library[sel[0]]
        self.logo_path.set(str(p))
        self.status.set("Sticker seçildi: "+p.name)
        messagebox.showinfo("Sticker",f"{p.name}\n\nOverlay olarak seçildi. Sağ paneldeki logo/overlay ayarından kullanılabilir.")

    def check_update(self):
        threading.Thread(target=self._update_worker, daemon=True).start()

    def _update_worker(self):
        self.after(0, lambda: self.status.set("Güncelleme kontrol ediliyor..."))
        try:
            cfg=json.loads((Path(__file__).resolve().parent/"update_config.json").read_text(encoding="utf-8-sig"))
            url=str(cfg.get("manifest_url","")).strip()
            if not url or url.startswith("BURAYA_"):
                self.after(0, lambda: messagebox.showinfo("Güncelleme",
                    "Otomatik güncelleme düğmesi hazır. İnternetten otomatik indirme için kalıcı güncelleme adresi tanımlanması gerekiyor."))
                self.after(0, lambda: self.status.set("Hazır"))
                return
            req=urllib.request.Request(url,headers={"User-Agent":"SolinajEditorUpdater"})
            with urllib.request.urlopen(req,timeout=20) as r:
                m=json.loads(r.read().decode("utf-8-sig"))
            remote=str(m.get("version","0.0.0"))
            def vt(v):
                return tuple(int(x) if x.isdigit() else 0 for x in (v.split(".")+["0","0"])[:3])
            if vt(remote)<=vt(APP_VERSION):
                self.after(0, lambda: messagebox.showinfo("Güncelleme","En güncel sürümü kullanıyorsun."))
                self.after(0, lambda: self.status.set("Hazır"))
                return
            package=str(m.get("package_url","")).strip()
            if not package: raise RuntimeError("Güncelleme paket adresi yok.")
            tmp=Path(tempfile.gettempdir())/f"SolinajEditor_{remote}.zip"
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
            self.after(0, lambda: self.status.set(f"V{remote} indiriliyor..."))

            expected=str(m.get("sha256","")).strip().lower()
            last_hash=""
            last_error=None
            for attempt in range(1, 4):
                try:
                    sep="&" if "?" in package else "?"
                    fresh_url=f"{package}{sep}v={remote}&attempt={attempt}&ts={int(time.time())}"
                    req=urllib.request.Request(
                        fresh_url,
                        headers={
                            "User-Agent":"SolinajEditorUpdater",
                            "Cache-Control":"no-cache",
                            "Pragma":"no-cache"
                        }
                    )
                    with urllib.request.urlopen(req,timeout=120) as r, open(tmp,"wb") as f:
                        total=int(r.headers.get("Content-Length") or 0); done=0
                        while True:
                            chunk=r.read(1024*1024)
                            if not chunk: break
                            f.write(chunk); done+=len(chunk)
                            if total: self.after(0, lambda p=done*100/total:self.progress.set(p))
                    if expected:
                        last_hash=hashlib.sha256(tmp.read_bytes()).hexdigest()
                        if last_hash!=expected:
                            raise RuntimeError(f"SHA256 uyuşmadı. Beklenen: {expected[:12]}... Alınan: {last_hash[:12]}...")
                    last_error=None
                    break
                except Exception as ex:
                    last_error=ex
                    try:
                        if tmp.exists():
                            tmp.unlink()
                    except Exception:
                        pass
                    if attempt < 3:
                        time.sleep(1)
            if last_error is not None:
                raise RuntimeError(f"Güncelleme paketi doğrulanamadı. {last_error}")
            root=Path(__file__).resolve().parent
            subprocess.Popen(["powershell.exe","-NoProfile","-ExecutionPolicy","Bypass","-File",
                              str(root/"AUTO_UPDATE_APPLY.ps1"),"-ZipPath",str(tmp),
                              "-InstallDir",str(root),"-Launcher",str(root/"SolinajEditor_Launcher.vbs")],
                             creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            self.after(500,self.destroy)
        except Exception as e:
            msg=str(e)
            self.after(0, lambda: messagebox.showerror("Güncelleme Hatası",msg))
            self.after(0, lambda: self.status.set("Güncelleme hatası"))

    def start_export(self):
        if not self.input_path.get() or not Path(self.input_path.get()).exists():
            messagebox.showwarning("Eksik", "Önce bir video seç ve timeline'a ekle.")
            return
        if not find_ffmpeg():
            messagebox.showerror("FFmpeg yok", "FFmpeg bulunamadı. README dosyasındaki kurulumu uygula.")
            return
        if not self.output_path.get():
            self.pick_output()
            if not self.output_path.get():
                return
        self.progress.set(0)
        self.status.set("Dışa aktarma hazırlanıyor...")
        threading.Thread(target=self._export_worker, daemon=True).start()

    def _export_worker(self):
        try:
            export_video(
                input_path=self.input_path.get(),
                output_path=self.output_path.get(),
                start_time=self.start_time.get(),
                end_time=self.end_time.get(),
                aspect=self.aspect.get(),
                speed=float(self.speed.get()),
                volume=float(self.volume.get()),
                text=self.overlay_text.get().strip(),
                logo_path=self.logo_path.get().strip(),
                music_path=self.selected_music_path,
                music_volume=float(self.music_volume.get()),
                progress_cb=self._on_progress,
                status_cb=self._on_status,
            )
            self.after(0, lambda:self._done(True, "Dışa aktarma tamamlandı."))
        except Exception as e:
            self.after(0, lambda:self._done(False, str(e)))

    def _on_progress(self, val):
        self.after(0, lambda:self.progress.set(max(0,min(100,val))))

    def _on_status(self, text):
        self.after(0, lambda:self.status.set(text))

    def _done(self, ok, msg):
        self.status.set(msg)
        if ok:
            self.progress.set(100)
            messagebox.showinfo("Tamam", msg)
        else:
            messagebox.showerror("Hata", msg)

    def _startup_check(self):
        if find_ffmpeg():
            self.status.set("Hazır • FFmpeg bulundu • Solinaj Editor V2")
        else:
            self.status.set("FFmpeg bulunamadı • KURULUM.bat veya README adımlarını uygula")

    def _bind_shortcuts(self):
        self.bind("<Control-o>", lambda e:self.import_media())
        self.bind("<Control-e>", lambda e:self.start_export())
        self.bind("<Delete>", lambda e:self.remove_clip())
        self.bind("<Control-b>", lambda e:self.split_clip())
        self.bind("<space>", lambda e:self.toggle_preview())
        self.bind("<Escape>", lambda e:self.stop_preview())

    def _fmt(self, sec):
        try:
            sec=int(float(sec or 0))
        except Exception:
            sec=0
        h=sec//3600; m=(sec%3600)//60; s=sec%60
        return f"{h:02d}:{m:02d}:{s:02d}"

    def _fmt_short(self, sec):
        try:
            sec=int(float(sec or 0))
        except Exception:
            sec=0
        if sec >= 3600:
            return self._fmt(sec)
        return f"{sec//60:02d}:{sec%60:02d}"

    def on_close(self):
        self._stop_preview_processes()
        self.settings["last_input"]=self.input_path.get()
        save_settings(self.settings)
        self.destroy()



# --- V2.4.0 CapCut-benzeri görünüm rötuşları ---
def _solinaj_capcut_polish(root):
    """Mevcut çalışan widget/callback yapısını bozmadan koyu masaüstü editör görünümü."""
    try:
        root.configure(bg="#111318")
        root.option_add("*Font", ("Segoe UI", 10))
        root.option_add("*Background", "#17191f")
        root.option_add("*Foreground", "#f2f3f5")
        root.option_add("*Button.Background", "#242730")
        root.option_add("*Button.Foreground", "#f2f3f5")
        root.option_add("*Entry.Background", "#20232b")
        root.option_add("*Entry.Foreground", "#f2f3f5")
        root.option_add("*Listbox.Background", "#15171c")
        root.option_add("*Listbox.Foreground", "#e8eaf0")
        root.option_add("*Listbox.selectBackground", "#3a7afe")
        root.option_add("*Listbox.selectForeground", "#ffffff")
        root.option_add("*Canvas.Background", "#0d0f13")
    except Exception:
        pass

if __name__ == "__main__":
    try:
        app=SolinajEditor()
        app.protocol("WM_DELETE_WINDOW", app.on_close)
        app.mainloop()
    except Exception:
        import traceback
        try:
            log_path = Path(__file__).resolve().parent / "solinaj_editor_crash.log"
            log_path.write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        try:
            import tkinter.messagebox as _mb
            _mb.showerror(
                "Solinaj Editor Başlatma Hatası",
                "Program açılırken bir hata oluştu.\n\n"
                "Ayrıntı: solinaj_editor_crash.log"
            )
        except Exception:
            pass
