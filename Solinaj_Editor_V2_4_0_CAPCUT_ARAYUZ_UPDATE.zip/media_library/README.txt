SOLINAJ EDITOR V2.1 MEDYA KÜTÜPHANESİ

music: Lisansına uygun MP3/WAV/M4A/AAC/OGG dosyalarını buraya ekleyebilirsiniz.
stickers: PNG/WEBP/JPG/JPEG emoji ve sticker dosyalarını buraya ekleyebilirsiniz.

Program telifli müzikleri paket içine gömmez. Müzik penceresindeki YouTube Ses Kitaplığı
ve Pixabay bağlantıları güvenli kaynak bulmayı kolaylaştırır. Her içeriğin lisans/atıf
koşullarını indirdiğiniz tarihte kontrol edin.
