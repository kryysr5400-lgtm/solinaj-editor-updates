﻿param([string]$ZipPath,[string]$InstallDir,[string]$Launcher)
$ErrorActionPreference="Stop"
Start-Sleep -Seconds 2
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$backup=Join-Path $InstallDir ("_update_backup\"+$stamp)
$temp=Join-Path $env:TEMP ("SolinajEditorUpdate_"+$stamp)
New-Item -ItemType Directory -Force -Path $backup,$temp | Out-Null
Get-ChildItem $InstallDir -Force | Where-Object {$_.Name -ne "_update_backup"} | ForEach-Object {Copy-Item $_.FullName $backup -Recurse -Force}
$settings=Join-Path $InstallDir "config\settings.json"
$settingsTemp=Join-Path $env:TEMP ("SolinajSettings_"+$stamp+".json")
if(Test-Path $settings){Copy-Item $settings $settingsTemp -Force}
Expand-Archive $ZipPath $temp -Force
$items=@(Get-ChildItem $temp -Force); $payload=$temp
if($items.Count -eq 1 -and $items[0].PSIsContainer){$payload=$items[0].FullName}
Get-ChildItem $payload -Force | ForEach-Object {Copy-Item $_.FullName $InstallDir -Recurse -Force}
if(Test-Path $settingsTemp){New-Item -ItemType Directory -Force -Path (Split-Path $settings)|Out-Null; Copy-Item $settingsTemp $settings -Force}
Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue
Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue
Start-Process "$env:WINDIR\System32\wscript.exe" -ArgumentList "`"$Launcher`""
