SOLINAJ EDITOR V2 — MASAÜSTÜ KURULUMU

1) ZIP dosyasını normal bir klasöre çıkar.
2) MASAUSTUNE_KUR.bat dosyasına çift tıkla.
3) Kurulum bittikten sonra masaüstünde:
   SOLINAJ EDITOR
   adlı uygulama simgesi oluşur.
4) Bundan sonra yalnızca bu simgeye çift tıklayarak programı açabilirsin.

Kurulum programı:
- Solinaj Editor'ü %LOCALAPPDATA%\SolinajEditorV2 içine kopyalar.
- Masaüstüne .lnk kısayolu oluşturur.
- SolinajEditor.ico simgesini kullanır.
- Başlat Menüsü > Solinaj içine de kısayol ekler.
- Programı arka planda pythonw ile açtığı için siyah komut penceresi göstermez.

V2'nin mevcut çalışma özellikleri korunmuştur.
