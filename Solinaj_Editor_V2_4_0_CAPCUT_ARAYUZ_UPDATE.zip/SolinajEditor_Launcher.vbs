Option Explicit
Dim shell, fso, appDir, appPy, pyw, cmd
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

appDir = fso.GetParentFolderName(WScript.ScriptFullName)
appPy = appDir & "\app.py"

pyw = ""
On Error Resume Next
pyw = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python313\pythonw.exe"
If Not fso.FileExists(pyw) Then pyw = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python312\pythonw.exe"
If Not fso.FileExists(pyw) Then pyw = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python311\pythonw.exe"
If Not fso.FileExists(pyw) Then
    pyw = "pythonw.exe"
End If
On Error GoTo 0

cmd = Chr(34) & pyw & Chr(34) & " " & Chr(34) & appPy & Chr(34)
shell.CurrentDirectory = appDir
shell.Run cmd, 0, False
