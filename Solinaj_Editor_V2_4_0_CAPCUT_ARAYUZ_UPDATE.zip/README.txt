SOLINAJ EDITOR V2.0 — CAPCUT BENZERİ WINDOWS ARAYÜZÜ
======================================================

Bu sürüm V1'in çalışan FFmpeg dışa aktarma altyapısını korur ve arayüzü
CapCut tarzı masaüstü video editör düzenine dönüştürür.

V2 ARAYÜZÜ
----------
- Windows 11 tarzı koyu masaüstü görünümü
- Sol: Medya kütüphanesi / içe aktarma
- Orta: Video önizleme alanı
- Sağ: Özellikler / format / hız / ses / yazı / logo / çıktı
- Alt: Timeline, video ve ses track'leri
- Timeline playhead
- Timeline zoom
- Böl / sil / geri / ileri araç çubuğu
- Ctrl+O medya ekle
- Ctrl+B kesme noktası
- Ctrl+E dışa aktar

V2 ÇALIŞAN ÖZELLİKLER
---------------------
- MP4/MKV/MOV/AVI/WEBM içe aktarma
- Video süresi okuma
- Başlangıç / bitiş kesme
- 16:9 YouTube
- 9:16 Shorts
- 1:1 kare
- Hız ayarı
- Ses ayarı
- Yazı overlay
- Logo / filigran
- H.264 MP4 dışa aktarma
- Render ilerleme çubuğu
- Seçilen videoyu Windows varsayılan oynatıcısında önizleme

NOT
---
Timeline V2'de profesyonel editör görünümü ve tek klip hızlı kurgu akışı için hazırdır.
Çoklu klip gerçek zaman çizgisi birleştirme, sürükle-bırak klip taşıma, gerçek kare-içi
preview, geçişler ve undo/redo motoru V3 için altyapı olarak planlanmıştır.

FFMPEG
------
FFmpeg PATH içinde olabilir veya:
Solinaj_Editor_V2_CapCut\ffmpeg\bin\ffmpeg.exe
Solinaj_Editor_V2_CapCut\ffmpeg\bin\ffprobe.exe

ÇALIŞTIRMA
----------
1) KURULUM.bat
2) CALISTIR.bat

GÜNCELLEME
----------
V1 korunabilir. V2 ayrı klasördür.
Sonraki sürümler V2 üzerine V3, V4 şeklinde hazırlanabilir.
