
from pathlib import Path
import json

CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"
SETTINGS_FILE = CONFIG_DIR / "settings.json"

DEFAULTS = {
    "last_input": "",
    "theme": "dark",
    "auto_check_updates": True
}

def load_settings():
    CONFIG_DIR.mkdir(exist_ok=True)
    if not SETTINGS_FILE.exists():
        return DEFAULTS.copy()
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        out = DEFAULTS.copy()
        out.update(data)
        return out
    except Exception:
        return DEFAULTS.copy()

def save_settings(data):
    CONFIG_DIR.mkdir(exist_ok=True)
    SETTINGS_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
