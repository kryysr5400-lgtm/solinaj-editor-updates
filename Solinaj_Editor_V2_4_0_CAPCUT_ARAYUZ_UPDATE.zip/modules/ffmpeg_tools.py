
from pathlib import Path
import subprocess
import shutil
import re
import os


def find_ffmpeg():
    candidates = [
        shutil.which("ffmpeg"),
        str(Path(__file__).resolve().parent.parent / "ffmpeg" / "bin" / "ffmpeg.exe"),
    ]
    for p in candidates:
        if p and Path(p).exists():
            return p
    return None



def find_ffplay():
    candidates = [
        shutil.which("ffplay"),
        str(Path(__file__).resolve().parent.parent / "ffmpeg" / "bin" / "ffplay.exe"),
    ]
    for p in candidates:
        if p and Path(p).exists():
            return p
    return None

def find_ffprobe():
    candidates = [
        shutil.which("ffprobe"),
        str(Path(__file__).resolve().parent.parent / "ffmpeg" / "bin" / "ffprobe.exe"),
    ]
    for p in candidates:
        if p and Path(p).exists():
            return p
    return None


def probe_duration(path):
    ffprobe = find_ffprobe()
    if not ffprobe:
        return None
    cmd = [
        ffprobe, "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        path
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, creationflags=_creationflags())
    if r.returncode != 0:
        return None
    return float(r.stdout.strip())


def parse_time(s):
    if s is None or s == "":
        return None
    parts = s.strip().split(":")
    try:
        if len(parts) == 3:
            h, m, sec = map(float, parts)
            return h*3600 + m*60 + sec
        if len(parts) == 2:
            m, sec = map(float, parts)
            return m*60 + sec
        return float(parts[0])
    except Exception:
        return None


def _escape_drawtext(text):
    return (
        text.replace("\\", "\\\\")
            .replace(":", r"\:")
            .replace("'", r"\'")
            .replace("%", r"\%")
    )


def build_filters(aspect, speed, volume, text, logo_path):
    vfilters = []
    afilters = []

    if aspect == "16:9 YouTube":
        vfilters.append("scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2")
    elif aspect == "9:16 Shorts":
        vfilters.append("scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920")
    elif aspect == "1:1 Kare":
        vfilters.append("scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080")

    if speed and abs(speed - 1.0) > 0.001:
        vfilters.append(f"setpts=PTS/{speed:.4f}")
        # atempo only supports 0.5-2.0, which matches GUI range
        afilters.append(f"atempo={speed:.4f}")

    if volume is not None and abs(volume - 1.0) > 0.001:
        afilters.append(f"volume={volume:.4f}")

    if text:
        safe = _escape_drawtext(text)
        # Windows'ta Arial genelde vardır; bulunamazsa drawtext font fallback kullanır.
        vfilters.append(
            "drawtext="
            f"text='{safe}':"
            "fontcolor=white:fontsize=48:"
            "box=1:boxcolor=black@0.45:boxborderw=14:"
            "x=(w-text_w)/2:y=h-text_h-80"
        )

    return vfilters, afilters


def export_video(input_path, output_path, start_time="", end_time="",
                 aspect="Orijinal", speed=1.0, volume=1.0,
                 text="", logo_path="", music_path="", music_volume=0.35, progress_cb=None, status_cb=None):
    ffmpeg = find_ffmpeg()
    if not ffmpeg:
        raise RuntimeError("FFmpeg bulunamadı.")

    start = parse_time(start_time) or 0.0
    end = parse_time(end_time)
    total_duration = None
    original = probe_duration(input_path)
    if end is not None and end > start:
        total_duration = end - start
    elif original:
        total_duration = max(0.1, original - start)

    cmd = [ffmpeg, "-y"]
    if start > 0:
        cmd += ["-ss", str(start)]
    cmd += ["-i", input_path]

    use_logo = bool(logo_path and Path(logo_path).exists())
    use_music = bool(music_path and Path(music_path).exists())
    logo_idx = None
    music_idx = None
    next_idx = 1
    if use_logo:
        logo_idx = next_idx
        cmd += ["-i", logo_path]
        next_idx += 1
    if use_music:
        music_idx = next_idx
        cmd += ["-stream_loop", "-1", "-i", music_path]
        next_idx += 1

    if end is not None and end > start:
        cmd += ["-t", str(end - start)]

    vfilters, afilters = build_filters(aspect, speed, volume, text, logo_path)

    complex_parts = []
    video_map = "0:v"
    audio_map = "0:a?"

    if use_logo:
        base_chain = ",".join(vfilters) if vfilters else "null"
        complex_parts.append(f"[0:v]{base_chain}[base]")
        complex_parts.append(f"[{logo_idx}:v]scale=180:-1[logo]")
        complex_parts.append("[base][logo]overlay=30:30[vout]")
        video_map = "[vout]"
    elif vfilters:
        complex_parts.append(f"[0:v]{','.join(vfilters)}[vout]")
        video_map = "[vout]"

    if use_music:
        orig_chain = ",".join(afilters) if afilters else "anull"
        mv = max(0.0, min(1.0, float(music_volume or 0.35)))
        complex_parts.append(f"[0:a]{orig_chain}[a0]")
        complex_parts.append(f"[{music_idx}:a]volume={mv:.3f},afade=t=in:st=0:d=0.8[bgm]")
        complex_parts.append("[a0][bgm]amix=inputs=2:duration=first:dropout_transition=2[aout]")
        audio_map = "[aout]"
    elif afilters:
        complex_parts.append(f"[0:a]{','.join(afilters)}[aout]")
        audio_map = "[aout]"

    if complex_parts:
        cmd += ["-filter_complex", ";".join(complex_parts), "-map", video_map, "-map", audio_map]
    else:
        cmd += ["-map", "0:v", "-map", "0:a?"]

    cmd += [
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-crf", "20",
        "-c:a", "aac",
        "-b:a", "192k",
        "-movflags", "+faststart",
        "-progress", "pipe:1",
        "-nostats",
        output_path
    ]

    if status_cb:
        status_cb("FFmpeg işliyor...")

    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, universal_newlines=True, creationflags=_creationflags()
    )

    try:
        if proc.stdout:
            for line in proc.stdout:
                line = line.strip()
                if line.startswith("out_time_ms=") and total_duration and total_duration > 0:
                    us = int(line.split("=",1)[1] or "0")
                    sec = us / 1_000_000.0
                    pct = (sec / total_duration) * 100.0
                    if progress_cb:
                        progress_cb(pct)
                elif line.startswith("progress="):
                    val = line.split("=",1)[1]
                    if status_cb:
                        status_cb("Dışa aktarılıyor..." if val != "end" else "Tamamlanıyor...")
        err = proc.stderr.read() if proc.stderr else ""
        code = proc.wait()
        if code != 0:
            tail = "\n".join(err.splitlines()[-12:])
            raise RuntimeError("FFmpeg işlemi başarısız oldu.\n\n" + tail)
    finally:
        if proc.poll() is None:
            proc.kill()


def _creationflags():
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
