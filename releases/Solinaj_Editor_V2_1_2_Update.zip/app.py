
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import threading
import os
import subprocess
import shutil
import webbrowser
import sys, json, urllib.request, tempfile, hashlib, re

from modules.ffmpeg_tools import find_ffmpeg, probe_duration, export_video
from modules.settings import load_settings, save_settings
from modules.versioning import APP_NAME, APP_VERSION, check_local_manifest

BG = "#0f1014"
PANEL = "#17181d"
PANEL2 = "#1d1f25"
BORDER = "#2a2d35"
TEXT = "#f4f6fa"
MUTED = "#9aa1ad"
ACCENT = "#38d9c5"
ACCENT_HOVER = "#2fc4b2"
BTN = "#282b33"
BTN_HOVER = "#343842"
TIMELINE_BG = "#111217"
TRACK = "#1c1f26"
CLIP = "#284b53"
AUDIO = "#34394a"
RED = "#ef5b64"


class SolinajEditor(tk.Tk):
    def __init__(self):
        super().__init__()
        self.music_library = []
        self.sticker_library = []
        self._load_builtin_media_library()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self._solinaj_media_menu_added = True
        media_menu = tk.Menu(self)
        library_menu = tk.Menu(media_menu, tearoff=0)
        library_menu.add_command(label="🎵 Telifsiz Müzik", command=self.open_music_library)
        library_menu.add_command(label="😀 Emoji & Sticker", command=self.open_sticker_library)
        media_menu.add_cascade(label="Medya Kütüphanesi", menu=library_menu)
        self.config(menu=media_menu)
        self.geometry("1480x900")
        self.minsize(1180, 760)
        self.configure(bg=BG)

        self.settings = load_settings()
        self.media_files = []
        self.selected_media = None
        self.duration = 0.0

        self.input_path = tk.StringVar()
        self.output_path = tk.StringVar()
        self.start_time = tk.StringVar(value="00:00:00")
        self.end_time = tk.StringVar(value="")
        self.aspect = tk.StringVar(value="16:9 YouTube")
        self.speed = tk.DoubleVar(value=1.0)
        self.volume = tk.DoubleVar(value=1.0)
        self.overlay_text = tk.StringVar(value="")
        self.logo_path = tk.StringVar(value="")
        self.status = tk.StringVar(value="Hazır")
        self.progress = tk.DoubleVar(value=0)
        self.playhead = tk.DoubleVar(value=0.0)
        self.timeline_zoom = tk.DoubleVar(value=1.0)

        self._style()
        self._build_ui()
        self._bind_shortcuts()
        self.after(300, self._startup_check)

    def _style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except Exception:
            pass
        s.configure("Treeview", background=PANEL2, fieldbackground=PANEL2, foreground=TEXT,
                    borderwidth=0, rowheight=30, font=("Segoe UI", 10))
        s.configure("Treeview.Heading", background=PANEL, foreground=MUTED, relief="flat",
                    font=("Segoe UI", 9, "bold"))
        s.map("Treeview", background=[("selected", "#2c3740")], foreground=[("selected", TEXT)])
        s.configure("TCombobox", fieldbackground=BTN, background=BTN, foreground=TEXT,
                    arrowcolor=TEXT, bordercolor=BORDER)
        s.configure("Horizontal.TProgressbar", troughcolor="#242730", background=ACCENT, bordercolor="#242730")
        s.configure("TPanedwindow", background=BG)

    def _button(self, parent, text, cmd=None, accent=False, width=None):
        bg = ACCENT if accent else BTN
        fg = "#07100f" if accent else TEXT
        b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                      activebackground=ACCENT_HOVER if accent else BTN_HOVER,
                      activeforeground=fg, relief="flat", bd=0,
                      font=("Segoe UI", 10, "bold" if accent else "normal"),
                      padx=14, pady=8, cursor="hand2", width=width)
        return b

    def _label(self, parent, text="", **kw):
        opts = dict(bg=PANEL, fg=TEXT, font=("Segoe UI", 10))
        opts.update(kw)
        return tk.Label(parent, text=text, **opts)

    def _build_ui(self):
        self._build_titlebar()
        self._build_main()
        self._build_statusbar()

    def _build_titlebar(self):
        bar = tk.Frame(self, bg="#14151a", height=58, highlightthickness=1, highlightbackground=BORDER)
        bar.pack(fill="x", side="top")
        bar.pack_propagate(False)

        left = tk.Frame(bar, bg="#14151a")
        left.pack(side="left", fill="y")
        tk.Label(left, text="◆", bg="#14151a", fg=ACCENT, font=("Segoe UI Symbol", 17, "bold")).pack(side="left", padx=(16,6))
        tk.Label(left, text="SOLINAJ EDITOR", bg="#14151a", fg=TEXT,
                 font=("Segoe UI", 15, "bold")).pack(side="left")
        tk.Label(left, text=f"  V{APP_VERSION}", bg="#14151a", fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left", pady=(4,0))

        center = tk.Frame(bar, bg="#14151a")
        center.pack(side="left", padx=40, fill="y")
        for t in ["Dosya", "Düzenle", "Görünüm", "Yardım"]:
            tk.Button(center, text=t, bg="#14151a", fg=MUTED, activebackground="#202228",
                      activeforeground=TEXT, relief="flat", bd=0, font=("Segoe UI", 9),
                      padx=10, pady=17).pack(side="left")

        right = tk.Frame(bar, bg="#14151a")
        right.pack(side="right", padx=12, fill="y")
        self._button(right, "↻  Güncelle", self.check_update).pack(side="left", padx=5, pady=10)
        self._button(right, "DIŞA AKTAR", self.start_export, accent=True).pack(side="left", padx=5, pady=10)

    def _build_main(self):
        outer = tk.PanedWindow(self, orient="vertical", bg=BORDER, sashwidth=5,
                               bd=0, relief="flat", sashrelief="flat")
        outer.pack(fill="both", expand=True)

        work = tk.Frame(outer, bg=BG)
        timeline = tk.Frame(outer, bg=TIMELINE_BG, height=285)
        outer.add(work, stretch="always", minsize=420)
        outer.add(timeline, stretch="never", minsize=230)

        main = tk.PanedWindow(work, orient="horizontal", bg=BORDER, sashwidth=5, bd=0)
        main.pack(fill="both", expand=True)

        media = tk.Frame(main, bg=PANEL, width=280)
        preview = tk.Frame(main, bg="#0b0c10", width=760)
        inspector = tk.Frame(main, bg=PANEL, width=330)
        main.add(media, minsize=230)
        main.add(preview, minsize=520)
        main.add(inspector, minsize=290)

        self._build_media_panel(media)
        self._build_preview(preview)
        self._build_inspector(inspector)
        self._build_timeline(timeline)

    def _build_media_panel(self, parent):
        hdr = tk.Frame(parent, bg=PANEL)
        hdr.pack(fill="x", padx=12, pady=(12,8))
        tk.Label(hdr, text="Medya", bg=PANEL, fg=TEXT, font=("Segoe UI", 12, "bold")).pack(side="left")
        self._button(hdr, "+ İçe Aktar", self.import_media, accent=True).pack(side="right")

        tabs = tk.Frame(parent, bg=PANEL)
        tabs.pack(fill="x", padx=12)
        for i, t in enumerate(["Yerel", "Ses", "Metin", "Geçiş", "Efekt"]):
            fg = TEXT if i == 0 else MUTED
            tk.Label(tabs, text=t, bg=PANEL, fg=fg, font=("Segoe UI", 9, "bold" if i==0 else "normal"),
                     padx=7, pady=7).pack(side="left")
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x")

        search = tk.Entry(parent, bg="#111319", fg=TEXT, insertbackground=TEXT, relief="flat",
                          font=("Segoe UI", 10))
        search.insert(0, "  Medyada ara")
        search.pack(fill="x", padx=12, pady=12, ipady=7)

        self.media_tree = ttk.Treeview(parent, columns=("type","dur"), show="headings", selectmode="browse")
        self.media_tree.heading("type", text="DOSYA")
        self.media_tree.heading("dur", text="SÜRE")
        self.media_tree.column("type", width=175, stretch=True)
        self.media_tree.column("dur", width=60, anchor="e", stretch=False)
        self.media_tree.pack(fill="both", expand=True, padx=12, pady=(0,12))
        self.media_tree.bind("<<TreeviewSelect>>", self._media_selected)
        self.media_tree.bind("<Double-1>", lambda e: self.add_selected_to_timeline())

        foot = tk.Frame(parent, bg=PANEL)
        foot.pack(fill="x", padx=12, pady=(0,12))
        self._button(foot, "＋ Timeline'a Ekle", self.add_selected_to_timeline).pack(fill="x")

    def _build_preview(self, parent):
        top = tk.Frame(parent, bg="#0b0c10")
        top.pack(fill="x", padx=12, pady=10)
        tk.Label(top, text="Önizleme", bg="#0b0c10", fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        self.preview_format = tk.Label(top, text="16:9", bg="#0b0c10", fg=MUTED, font=("Segoe UI", 9))
        self.preview_format.pack(side="right")

        stage_wrap = tk.Frame(parent, bg="#0b0c10")
        stage_wrap.pack(fill="both", expand=True, padx=18, pady=(0,6))
        self.stage = tk.Canvas(stage_wrap, bg="#050608", highlightthickness=1, highlightbackground="#202229")
        self.stage.pack(fill="both", expand=True)
        self.stage.bind("<Configure>", self._draw_preview_placeholder)

        controls = tk.Frame(parent, bg="#0b0c10")
        controls.pack(fill="x", padx=18, pady=(0,10))
        self.time_lbl = tk.Label(controls, text="00:00:00 / 00:00:00", bg="#0b0c10",
                                 fg=MUTED, font=("Consolas", 9))
        self.time_lbl.pack(side="left")
        center = tk.Frame(controls, bg="#0b0c10")
        center.place(relx=.5, rely=.5, anchor="center")
        for text, cmd in [("⏮", lambda: self._seek(0)), ("◀", lambda: self._step(-1)),
                          ("▶", self._preview_open), ("▶▶", lambda: self._step(1)), ("⏭", lambda: self._seek(self.duration))]:
            tk.Button(center, text=text, command=cmd, bg="#0b0c10", fg=TEXT,
                      activebackground="#191b21", activeforeground=TEXT,
                      relief="flat", bd=0, padx=7, pady=4).pack(side="left")
        tk.Label(controls, text="100%", bg="#0b0c10", fg=MUTED, font=("Segoe UI", 9)).pack(side="right")

    def _build_inspector(self, parent):
        hdr = tk.Frame(parent, bg=PANEL)
        hdr.pack(fill="x", padx=14, pady=(13,9))
        tk.Label(hdr, text="Özellikler", bg=PANEL, fg=TEXT, font=("Segoe UI", 12, "bold")).pack(side="left")
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x")

        canvas = tk.Canvas(parent, bg=PANEL, highlightthickness=0)
        scroll = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=PANEL)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=inner, anchor="nw", width=310)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self._inspector_section(inner, "Temel")
        self._combo(inner, "Tuval / Format", self.aspect,
                    ["Orijinal", "16:9 YouTube", "9:16 Shorts", "1:1 Kare"],
                    callback=self._format_changed)
        self._entry(inner, "Başlangıç", self.start_time)
        self._entry(inner, "Bitiş", self.end_time)

        self._inspector_section(inner, "Video")
        self._scale(inner, "Hız", self.speed, 0.5, 2.0, suffix="x")
        self._scale(inner, "Ses", self.volume, 0.0, 2.0, suffix="x")

        self._inspector_section(inner, "Metin")
        self._entry(inner, "Ekran Yazısı", self.overlay_text)

        self._inspector_section(inner, "Logo / Filigran")
        lr = tk.Frame(inner, bg=PANEL)
        lr.pack(fill="x", padx=14, pady=(4,10))
        tk.Entry(lr, textvariable=self.logo_path, bg="#111319", fg=TEXT, insertbackground=TEXT,
                 relief="flat", font=("Segoe UI", 9)).pack(side="left", fill="x", expand=True, ipady=7)
        self._button(lr, "Seç", self.pick_logo).pack(side="left", padx=(6,0))

        self._inspector_section(inner, "Çıktı")
        self._entry(inner, "Kayıt Yolu", self.output_path)
        self._button(inner, "Kaydetme Yerini Seç", self.pick_output).pack(fill="x", padx=14, pady=(0,10))

    def _inspector_section(self, parent, title):
        tk.Label(parent, text=title, bg=PANEL, fg=TEXT, font=("Segoe UI", 10, "bold"),
                 anchor="w").pack(fill="x", padx=14, pady=(14,5))

    def _entry(self, parent, label, var):
        tk.Label(parent, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=14)
        tk.Entry(parent, textvariable=var, bg="#111319", fg=TEXT, insertbackground=TEXT, relief="flat",
                 font=("Segoe UI", 9)).pack(fill="x", padx=14, pady=(3,8), ipady=7)

    def _combo(self, parent, label, var, values, callback=None):
        tk.Label(parent, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=14)
        cb = ttk.Combobox(parent, textvariable=var, values=values, state="readonly")
        cb.pack(fill="x", padx=14, pady=(3,8))
        if callback:
            cb.bind("<<ComboboxSelected>>", lambda e: callback())

    def _scale(self, parent, label, var, mn, mx, suffix=""):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", padx=14)
        tk.Label(row, text=label, bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        val = tk.Label(row, text="", bg=PANEL, fg=TEXT, font=("Segoe UI", 9))
        val.pack(side="right")
        def refresh(*_):
            val.config(text=f"{var.get():.2f}{suffix}")
        var.trace_add("write", refresh)
        refresh()
        tk.Scale(parent, variable=var, from_=mn, to=mx, resolution=.05, orient="horizontal",
                 bg=PANEL, fg=TEXT, troughcolor="#2a2d35", activebackground=ACCENT,
                 highlightthickness=0, bd=0, showvalue=False).pack(fill="x", padx=14, pady=(0,8))

    def _build_timeline(self, parent):
        tool = tk.Frame(parent, bg="#17191f", height=44)
        tool.pack(fill="x")
        tool.pack_propagate(False)
        left = tk.Frame(tool, bg="#17191f")
        left.pack(side="left", padx=10)
        for t, cmd in [("✂ Böl", self.split_clip), ("🗑 Sil", self.remove_clip),
                       ("↶ Geri", lambda: self.status.set("Geri alma: V2 arayüz altyapısı hazır")),
                       ("↷ İleri", lambda: self.status.set("İleri alma: V2 arayüz altyapısı hazır"))]:
            self._button(left, t, cmd).pack(side="left", padx=3, pady=6)

        right = tk.Frame(tool, bg="#17191f")
        right.pack(side="right", padx=10)
        tk.Label(right, text="Timeline", bg="#17191f", fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        tk.Scale(right, variable=self.timeline_zoom, from_=0.5, to=3.0, resolution=.1,
                 orient="horizontal", bg="#17191f", fg=TEXT, troughcolor="#2a2d35",
                 highlightthickness=0, bd=0, showvalue=False,
                 command=lambda x:self._draw_timeline()).pack(side="left", padx=8)

        self.timeline = tk.Canvas(parent, bg=TIMELINE_BG, highlightthickness=0)
        self.timeline.pack(fill="both", expand=True)
        self.timeline.bind("<Configure>", lambda e:self._draw_timeline())
        self.timeline.bind("<Button-1>", self._timeline_click)

    def _build_statusbar(self):
        bar = tk.Frame(self, bg="#14151a", height=34, highlightthickness=1, highlightbackground=BORDER)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        tk.Label(bar, textvariable=self.status, bg="#14151a", fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left", padx=12)
        ttk.Progressbar(bar, variable=self.progress, maximum=100, style="Horizontal.TProgressbar",
                        length=220).pack(side="right", padx=12, pady=9)

    def _draw_preview_placeholder(self, event=None):
        c = self.stage
        c.delete("all")
        w, h = max(1, c.winfo_width()), max(1, c.winfo_height())
        if self.aspect.get() == "9:16 Shorts":
            rw = min(w*.48, h*9/16)
            rh = rw*16/9
        elif self.aspect.get() == "1:1 Kare":
            rw = rh = min(w*.72, h*.72)
        else:
            rw = min(w*.86, h*16/9)
            rh = rw*9/16
        x1, y1 = (w-rw)/2, (h-rh)/2
        x2, y2 = x1+rw, y1+rh
        c.create_rectangle(x1, y1, x2, y2, fill="#08090c", outline="#343741")
        if self.selected_media:
            c.create_text(w/2, h/2-16, text=Path(self.selected_media).name,
                          fill=TEXT, font=("Segoe UI", 14, "bold"), width=max(200,int(rw*.75)))
            c.create_text(w/2, h/2+18, text="▶  Windows oynatıcısında açmak için oynat düğmesine bas",
                          fill=MUTED, font=("Segoe UI", 9))
        else:
            c.create_text(w/2, h/2-12, text="MEDYA İÇE AKTAR",
                          fill=TEXT, font=("Segoe UI", 18, "bold"))
            c.create_text(w/2, h/2+20, text="Videonu sol panelden ekle ve timeline'a gönder",
                          fill=MUTED, font=("Segoe UI", 10))

    def _draw_timeline(self):
        c = self.timeline
        c.delete("all")
        w, h = max(1,c.winfo_width()), max(1,c.winfo_height())
        label_w = 105
        ruler_h = 28
        track_h = 52
        c.create_rectangle(0,0,w,h,fill=TIMELINE_BG,outline="")
        c.create_rectangle(0,0,w,ruler_h,fill="#17191f",outline="")
        c.create_text(12, ruler_h/2, text="00:00", fill=MUTED, anchor="w", font=("Consolas",8))

        dur = max(60.0, self.duration or 60.0)
        px_per_sec = max(2.0, (w-label_w)/dur) * self.timeline_zoom.get()
        major = 10 if px_per_sec < 8 else 5
        t = 0
        while t <= dur:
            x = label_w + t*px_per_sec
            if x > w: break
            c.create_line(x, 20, x, ruler_h, fill="#4a4d57")
            c.create_text(x+2, 8, text=self._fmt_short(t), fill=MUTED, anchor="nw", font=("Consolas",7))
            t += major

        tracks = [("V1  Video", TRACK), ("V2  Overlay", TRACK), ("A1  Ses", TRACK)]
        for i,(name,bg) in enumerate(tracks):
            y1 = ruler_h + i*track_h
            y2 = y1 + track_h - 2
            c.create_rectangle(0,y1,label_w-2,y2,fill="#17191f",outline="")
            c.create_text(12,(y1+y2)/2,text=name,fill=MUTED,anchor="w",font=("Segoe UI",8,"bold"))
            c.create_rectangle(label_w,y1,w,y2,fill=bg,outline="")

        if self.selected_media:
            clip_dur = self.duration or 30
            clip_w = min(w-label_w-12, max(140, clip_dur*px_per_sec))
            y1 = ruler_h+4
            y2 = ruler_h+track_h-6
            c.create_rectangle(label_w+4,y1,label_w+clip_w,y2,fill=CLIP,outline=ACCENT,width=1,tags=("clip",))
            c.create_text(label_w+12,(y1+y2)/2,text=Path(self.selected_media).name,
                          fill=TEXT,anchor="w",font=("Segoe UI",8,"bold"),width=max(80,int(clip_w-30)),tags=("clip",))
            # audio representation
            ay1 = ruler_h + 2*track_h + 4
            ay2 = ay1 + track_h - 10
            c.create_rectangle(label_w+4,ay1,label_w+clip_w,ay2,fill=AUDIO,outline="#62687a",tags=("clip",))
            # fake waveform
            x = label_w+12
            mid=(ay1+ay2)/2
            while x < label_w+clip_w-8:
                amp = 5 + int((x*7)%13)
                c.create_line(x,mid-amp,x,mid+amp,fill="#8e96ad")
                x += 7

        # playhead
        play_x = label_w + self.playhead.get()*px_per_sec
        play_x = min(max(label_w, play_x), w)
        c.create_line(play_x,0,play_x,h,fill=RED,width=2)
        c.create_polygon(play_x-5,0,play_x+5,0,play_x,7,fill=RED,outline="")

    def import_media(self):
        paths = filedialog.askopenfilenames(
            title="Medya içe aktar",
            filetypes=[("Medya", "*.mp4 *.mkv *.mov *.avi *.webm *.mp3 *.wav *.m4a"),
                       ("Tüm dosyalar","*.*")]
        )
        for p in paths:
            if p not in self.media_files:
                self.media_files.append(p)
                dur = probe_duration(p) if Path(p).suffix.lower() not in {".mp3",".wav",".m4a"} else None
                self.media_tree.insert("", "end", iid=str(len(self.media_files)-1),
                                       values=(Path(p).name, self._fmt_short(dur) if dur else "—"))
        if paths and self.selected_media is None:
            first = str(len(self.media_files)-len(paths))
            try:
                self.media_tree.selection_set(first)
                self._select_media_path(self.media_files[int(first)])
            except Exception:
                pass

    def _media_selected(self, event=None):
        sel = self.media_tree.selection()
        if not sel:
            return
        try:
            p = self.media_files[int(sel[0])]
        except Exception:
            return
        self._select_media_path(p)

    def _select_media_path(self, p):
        self.selected_media = p
        self.input_path.set(p)
        try:
            self.duration = probe_duration(p) or 0
        except Exception:
            self.duration = 0
        self.start_time.set("00:00:00")
        if self.duration:
            self.end_time.set(self._fmt(self.duration))
        pp = Path(p)
        self.output_path.set(str(pp.with_name(pp.stem + "_solinaj_edit.mp4")))
        self.playhead.set(0)
        self.time_lbl.config(text=f"00:00:00 / {self._fmt(self.duration)}")
        self.status.set(f"Seçildi: {pp.name}")
        self._draw_preview_placeholder()
        self._draw_timeline()

    def add_selected_to_timeline(self):
        if not self.selected_media:
            messagebox.showinfo("Timeline", "Önce soldan bir medya seç.")
            return
        self.status.set(f"Timeline'a eklendi: {Path(self.selected_media).name}")
        self._draw_timeline()

    def _timeline_click(self, e):
        label_w=105
        if e.x < label_w:
            return
        w=max(1,self.timeline.winfo_width())
        dur=max(60.0,self.duration or 60.0)
        px=max(2.0,(w-label_w)/dur)*self.timeline_zoom.get()
        sec=max(0,(e.x-label_w)/px)
        if self.duration:
            sec=min(sec,self.duration)
        self._seek(sec)

    def _seek(self, sec):
        self.playhead.set(float(sec or 0))
        self.time_lbl.config(text=f"{self._fmt(self.playhead.get())} / {self._fmt(self.duration)}")
        self._draw_timeline()

    def _step(self, delta):
        self._seek(max(0, min(self.duration or 999999, self.playhead.get()+delta)))

    def split_clip(self):
        if not self.selected_media:
            return
        t = self.playhead.get()
        self.start_time.set(self._fmt(t))
        self.status.set(f"Kesme noktası ayarlandı: {self._fmt(t)}")

    def remove_clip(self):
        if not self.selected_media:
            return
        self.status.set("Timeline görünümünden klip kaldırıldı (dosya silinmedi).")
        self.selected_media=None
        self.input_path.set("")
        self.duration=0
        self.playhead.set(0)
        self._draw_preview_placeholder()
        self._draw_timeline()

    def _preview_open(self):
        p = self.selected_media
        if not p or not Path(p).exists():
            return
        try:
            os.startfile(p)
            self.status.set("Video Windows varsayılan oynatıcısında açıldı.")
        except Exception as e:
            messagebox.showerror("Önizleme", str(e))

    def _format_changed(self):
        fmt = self.aspect.get()
        self.preview_format.config(text="9:16" if "9:16" in fmt else "1:1" if "1:1" in fmt else "16:9")
        self._draw_preview_placeholder()

    def pick_output(self):
        p = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4","*.mp4")])
        if p:
            self.output_path.set(p)

    def pick_logo(self):
        p = filedialog.askopenfilename(filetypes=[("Görsel","*.png *.jpg *.jpeg *.webp")])
        if p:
            self.logo_path.set(p)


    def _load_builtin_media_library(self):
        """Yerel medya kütüphanesini yükler. Telifli dosyaları paket içine gömmez."""
        base = Path(__file__).resolve().parent
        lib = base / "media_library"
        music = lib / "music"
        stickers = lib / "stickers"
        music.mkdir(parents=True, exist_ok=True)
        stickers.mkdir(parents=True, exist_ok=True)
        self.music_library = [p for p in music.rglob("*") if p.suffix.lower() in {".mp3",".wav",".m4a",".aac",".ogg"}]
        self.sticker_library = [p for p in stickers.rglob("*") if p.suffix.lower() in {".png",".webp",".jpg",".jpeg"}]

    def open_music_library(self):
        win = tk.Toplevel(self)
        win.title("🎵 Telifsiz Müzik Kütüphanesi")
        win.geometry("760x520")
        win.configure(bg="#15171b")
        tk.Label(win,text="🎵 TELİFSİZ MÜZİK",font=("Segoe UI",18,"bold"),fg="white",bg="#15171b").pack(pady=(18,4))
        tk.Label(win,text="İndirdiğin lisanslı müzikleri kütüphaneye ekle; sonra projede kullan.",font=("Segoe UI",10),fg="#aeb4bf",bg="#15171b").pack()
        bar=tk.Frame(win,bg="#15171b"); bar.pack(fill="x",padx=18,pady=14)
        tk.Button(bar,text="＋ Müzik Ekle",command=lambda:self._add_music_files(lst),padx=12,pady=7).pack(side="left",padx=4)
        tk.Button(bar,text="▶ YouTube Ses Kitaplığı",command=lambda:webbrowser.open("https://www.youtube.com/audiolibrary"),padx=12,pady=7).pack(side="left",padx=4)
        tk.Button(bar,text="▶ Pixabay Music",command=lambda:webbrowser.open("https://pixabay.com/music/"),padx=12,pady=7).pack(side="left",padx=4)
        lst=tk.Listbox(win,bg="#202329",fg="white",selectbackground="#3a404a",font=("Segoe UI",10))
        lst.pack(fill="both",expand=True,padx=18,pady=(0,10))
        self._refresh_music_list(lst)
        foot=tk.Frame(win,bg="#15171b"); foot.pack(fill="x",padx=18,pady=(0,16))
        tk.Button(foot,text="Projeye / Timeline'a Ekle",command=lambda:self._use_selected_music(lst),padx=12,pady=7).pack(side="left")
        tk.Label(foot,text="Not: Kaynağın lisans/atıf şartlarını kontrol et.",fg="#f0c674",bg="#15171b").pack(side="right")

    def _refresh_music_list(self, lst):
        self._load_builtin_media_library()
        lst.delete(0,"end")
        for p in self.music_library:
            lst.insert("end", p.name)

    def _add_music_files(self, lst):
        files=filedialog.askopenfilenames(title="Müzik seç",filetypes=[("Ses dosyaları","*.mp3 *.wav *.m4a *.aac *.ogg"),("Tüm dosyalar","*.*")])
        if not files: return
        dest=Path(__file__).resolve().parent/"media_library"/"music"
        for f in files:
            src=Path(f); target=dest/src.name
            if target.exists():
                target=dest/(src.stem+"_2"+src.suffix)
            shutil.copy2(src,target)
        self._refresh_music_list(lst)

    def _use_selected_music(self, lst):
        sel=lst.curselection()
        if not sel:
            messagebox.showwarning("Müzik","Önce bir müzik seç.")
            return
        p=self.music_library[sel[0]]
        # V2 tek-klip motorunu bozmadan seçimi proje durumuna kaydet.
        self.selected_music_path=str(p)
        self.status.set("Müzik seçildi: "+p.name)
        messagebox.showinfo("Müzik",f"{p.name}\n\nProjeye müzik olarak seçildi. V2.1 zaman çizelgesinde A1 müzik katmanı için hazır.")

    def open_sticker_library(self):
        win=tk.Toplevel(self)
        win.title("😀 Emoji & Sticker Kütüphanesi")
        win.geometry("720x500")
        win.configure(bg="#15171b")
        tk.Label(win,text="😀 EMOJİ & STICKER",font=("Segoe UI",18,"bold"),fg="white",bg="#15171b").pack(pady=(18,4))
        tk.Label(win,text="PNG / WEBP görsellerini ekle ve video overlay'i olarak kullan.",font=("Segoe UI",10),fg="#aeb4bf",bg="#15171b").pack()
        bar=tk.Frame(win,bg="#15171b"); bar.pack(fill="x",padx=18,pady=14)
        tk.Button(bar,text="＋ Sticker / Emoji Ekle",command=lambda:self._add_sticker_files(lst),padx=12,pady=7).pack(side="left")
        lst=tk.Listbox(win,bg="#202329",fg="white",selectbackground="#3a404a",font=("Segoe UI",10))
        lst.pack(fill="both",expand=True,padx=18,pady=(0,10))
        self._refresh_sticker_list(lst)
        tk.Button(win,text="Videoya Overlay Olarak Seç",command=lambda:self._use_selected_sticker(lst),padx=12,pady=7).pack(pady=(0,16))

    def _refresh_sticker_list(self,lst):
        self._load_builtin_media_library()
        lst.delete(0,"end")
        for p in self.sticker_library: lst.insert("end",p.name)

    def _add_sticker_files(self,lst):
        files=filedialog.askopenfilenames(title="Sticker/emoji seç",filetypes=[("Görseller","*.png *.webp *.jpg *.jpeg"),("Tüm dosyalar","*.*")])
        if not files:return
        dest=Path(__file__).resolve().parent/"media_library"/"stickers"
        for f in files:
            src=Path(f); target=dest/src.name
            if target.exists(): target=dest/(src.stem+"_2"+src.suffix)
            shutil.copy2(src,target)
        self._refresh_sticker_list(lst)

    def _use_selected_sticker(self,lst):
        sel=lst.curselection()
        if not sel:
            messagebox.showwarning("Sticker","Önce bir sticker seç.")
            return
        p=self.sticker_library[sel[0]]
        self.logo_path.set(str(p))
        self.status.set("Sticker seçildi: "+p.name)
        messagebox.showinfo("Sticker",f"{p.name}\n\nOverlay olarak seçildi. Sağ paneldeki logo/overlay ayarından kullanılabilir.")

    def check_update(self):
        threading.Thread(target=self._update_worker, daemon=True).start()

    def _update_worker(self):
        self.after(0, lambda: self.status.set("Güncelleme kontrol ediliyor..."))
        try:
            cfg=json.loads((Path(__file__).resolve().parent/"update_config.json").read_text(encoding="utf-8-sig"))
            url=str(cfg.get("manifest_url","")).strip()
            if not url or url.startswith("BURAYA_"):
                self.after(0, lambda: messagebox.showinfo("Güncelleme",
                    "Otomatik güncelleme düğmesi hazır. İnternetten otomatik indirme için kalıcı güncelleme adresi tanımlanması gerekiyor."))
                self.after(0, lambda: self.status.set("Hazır"))
                return
            req=urllib.request.Request(url,headers={"User-Agent":"SolinajEditorUpdater"})
            with urllib.request.urlopen(req,timeout=20) as r:
                m=json.loads(r.read().decode("utf-8-sig"))
            remote=str(m.get("version","0.0.0"))
            def vt(v):
                return tuple(int(x) if x.isdigit() else 0 for x in (v.split(".")+["0","0"])[:3])
            if vt(remote)<=vt(APP_VERSION):
                self.after(0, lambda: messagebox.showinfo("Güncelleme","En güncel sürümü kullanıyorsun."))
                self.after(0, lambda: self.status.set("Hazır"))
                return
            package=str(m.get("package_url","")).strip()
            if not package: raise RuntimeError("Güncelleme paket adresi yok.")
            tmp=Path(tempfile.gettempdir())/f"SolinajEditor_{remote}.zip"
            self.after(0, lambda: self.status.set(f"V{remote} indiriliyor..."))
            with urllib.request.urlopen(urllib.request.Request(package,headers={"User-Agent":"SolinajEditorUpdater"}),timeout=120) as r, open(tmp,"wb") as f:
                total=int(r.headers.get("Content-Length") or 0); done=0
                while True:
                    chunk=r.read(1024*1024)
                    if not chunk: break
                    f.write(chunk); done+=len(chunk)
                    if total: self.after(0, lambda p=done*100/total:self.progress.set(p))
            expected=str(m.get("sha256","")).strip().lower()
            if expected:
                h=hashlib.sha256(tmp.read_bytes()).hexdigest()
                if h!=expected: raise RuntimeError("Güncelleme paketi doğrulanamadı.")
            root=Path(__file__).resolve().parent
            subprocess.Popen(["powershell.exe","-NoProfile","-ExecutionPolicy","Bypass","-File",
                              str(root/"AUTO_UPDATE_APPLY.ps1"),"-ZipPath",str(tmp),
                              "-InstallDir",str(root),"-Launcher",str(root/"SolinajEditor_Launcher.vbs")],
                             creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            self.after(500,self.destroy)
        except Exception as e:
            msg=str(e)
            self.after(0, lambda: messagebox.showerror("Güncelleme Hatası",msg))
            self.after(0, lambda: self.status.set("Güncelleme hatası"))

    def start_export(self):
        if not self.input_path.get() or not Path(self.input_path.get()).exists():
            messagebox.showwarning("Eksik", "Önce bir video seç ve timeline'a ekle.")
            return
        if not find_ffmpeg():
            messagebox.showerror("FFmpeg yok", "FFmpeg bulunamadı. README dosyasındaki kurulumu uygula.")
            return
        if not self.output_path.get():
            self.pick_output()
            if not self.output_path.get():
                return
        self.progress.set(0)
        self.status.set("Dışa aktarma hazırlanıyor...")
        threading.Thread(target=self._export_worker, daemon=True).start()

    def _export_worker(self):
        try:
            export_video(
                input_path=self.input_path.get(),
                output_path=self.output_path.get(),
                start_time=self.start_time.get(),
                end_time=self.end_time.get(),
                aspect=self.aspect.get(),
                speed=float(self.speed.get()),
                volume=float(self.volume.get()),
                text=self.overlay_text.get().strip(),
                logo_path=self.logo_path.get().strip(),
                progress_cb=self._on_progress,
                status_cb=self._on_status,
            )
            self.after(0, lambda:self._done(True, "Dışa aktarma tamamlandı."))
        except Exception as e:
            self.after(0, lambda:self._done(False, str(e)))

    def _on_progress(self, val):
        self.after(0, lambda:self.progress.set(max(0,min(100,val))))

    def _on_status(self, text):
        self.after(0, lambda:self.status.set(text))

    def _done(self, ok, msg):
        self.status.set(msg)
        if ok:
            self.progress.set(100)
            messagebox.showinfo("Tamam", msg)
        else:
            messagebox.showerror("Hata", msg)

    def _startup_check(self):
        if find_ffmpeg():
            self.status.set("Hazır • FFmpeg bulundu • Solinaj Editor V2")
        else:
            self.status.set("FFmpeg bulunamadı • KURULUM.bat veya README adımlarını uygula")

    def _bind_shortcuts(self):
        self.bind("<Control-o>", lambda e:self.import_media())
        self.bind("<Control-e>", lambda e:self.start_export())
        self.bind("<Delete>", lambda e:self.remove_clip())
        self.bind("<Control-b>", lambda e:self.split_clip())

    def _fmt(self, sec):
        try:
            sec=int(float(sec or 0))
        except Exception:
            sec=0
        h=sec//3600; m=(sec%3600)//60; s=sec%60
        return f"{h:02d}:{m:02d}:{s:02d}"

    def _fmt_short(self, sec):
        try:
            sec=int(float(sec or 0))
        except Exception:
            sec=0
        if sec >= 3600:
            return self._fmt(sec)
        return f"{sec//60:02d}:{sec%60:02d}"

    def on_close(self):
        self.settings["last_input"]=self.input_path.get()
        save_settings(self.settings)
        self.destroy()


if __name__ == "__main__":
    app=SolinajEditor()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()
